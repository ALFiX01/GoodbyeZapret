@echo off
cd /d "%~dp0" >nul 2>&1
:: Copyright (C) 2025 ALFiX, Inc.
:: Any tampering with the program code is forbidden (Запрещены любые вмешательства)

:: Запуск от имени админа
if not "%1"=="am_admin" (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -WorkingDirectory '%~dp0' -Verb RunAs -ArgumentList 'am_admin diag_checked'" & exit /b
)

:: Ранняя диагностика пути запуска и config.txt
if /i not "%~2"=="diag_checked" if exist "%~dp0StartupDiagnostics.ps1" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0StartupDiagnostics.ps1" -LauncherPath "%~f0" -Quiet
    if errorlevel 1 (
        echo.
        pause
        exit /b 1
    )
)

:: Получаем путь к родительской папке и проверяем на пробелы
set "ParentDirPathForCheck=%~dp0"
if "%ParentDirPathForCheck:~-1%"=="\" set "ParentDirPathForCheck=%ParentDirPathForCheck:~0,-1%"

:: Включаем для манипуляции переменными
setlocal EnableDelayedExpansion

set "ErrorCount=0"

:: Получаем путь к родительской папке
set "ParentDirPath=%ParentDirPathForCheck%"


:: Version information   Stable / Beta / Alpha
set "Current_GoodbyeZapret_version=4.2.2"
set "Current_GoodbyeZapret_version_code=4A2F1"
set "branch=Stable"
set "beta_code=0"

chcp 65001 >nul 2>&1

:: Инициализируем конфигурационный файл
if not exist "%USERPROFILE%\AppData\Roaming\GoodbyeZapret" md "%USERPROFILE%\AppData\Roaming\GoodbyeZapret"
set "CONFIG_FILE=%USERPROFILE%\AppData\Roaming\GoodbyeZapret\config.txt"

if not exist "%CONFIG_FILE%" call :InitConfigFromRegistry
REM call :SyncTextPresets >nul 2>&1

REM Читаем значение текущего конфига из config.txt
set "GoodbyeZapret_Config="
call :ReadConfig GoodbyeZapret_Config
if "%GoodbyeZapret_Config%"=="NotFound" (
    REM Если переменная не найдена, установите значение по умолчанию
    set "GoodbyeZapret_Config=Не выбран"
)

call :ui_header


REM Проверка, выполнялась ли настройка ранее

call :ReadConfig FirstLaunch
if "%FirstLaunch%"=="NotFound" (
    REM Если переменная не найдена, установите значение по умолчанию
    set "FirstLaunch=1"
)

if "%FirstLaunch%"=="0" (
    goto :skip_checks
)

call :ui_info "Первый запуск, выполняю проверку и настройку..."


call :ReadConfig WinVer

rem 2) Если ключ отсутствует — записать текущую версию
if "%WinVer%"=="NotFound" (
    chcp 850 >nul 2>&1
    for /f "usebackq delims=" %%a in (`powershell -Command "(Get-CimInstance Win32_OperatingSystem).Caption"`) do (
        chcp 65001 >nul 2>&1
        set "WinVersion=%%a"

        REM Проверяем, является ли система Windows 11
        echo !WinVersion! | find /i "11" >nul
        if not errorlevel 1 (
            set "WinVer=11"
            call :WriteConfig WinVer "11"
            echo Set Win Version - 11
        ) else (
            REM Проверяем, является ли система Windows 10
            echo !WinVersion! | find /i "10" >nul
            if not errorlevel 1 (
                set "WinVer=10"
                call :WriteConfig WinVer "10"
                echo Set Win Version - 10
            )
        )
    )
)

REM По завершению создаём метку в реестре
call :WriteConfig FirstLaunch 0

REM /// Language ///
:: Получение информации о текущем языке интерфейса и выход, если язык не ru-RU
for /f "tokens=3" %%i in ('reg query "HKCU\Control Panel\International" /v "LocaleName" ^| findstr /i "LocaleName"') do set "WinLang=%%i"
if /I "%WinLang%" NEQ "ru-Ru" (
    cls
    echo.
    echo   Error 01: Invalid Windows interface language. GoodbyeZapret may encounter problems.
    echo.
    echo   Required: ru-RU
    echo   Current:  %WinLang%
    timeout /t 5 >nul
    call :ui_header
)

:skip_checks

REM /// GoodbyeZapret Version ///
rem 1) Прочитать текущую версию из config.txt
call :ReadConfig GoodbyeZapret_Version

rem 2) Если ключ отсутствует — записать текущую версию
if "%GoodbyeZapret_Version%"=="NotFound" (
    call :WriteConfig GoodbyeZapret_Version "%Current_GoodbyeZapret_version%"
) else (
    rem 3) Если отличается — обновить версию в config.txt
    if /i not "%GoodbyeZapret_Version%"=="%Current_GoodbyeZapret_version%" (
        call :WriteConfig GoodbyeZapret_Version "%Current_GoodbyeZapret_version%"
    )
)

rem /// GoodbyeZapret_Version_code — новый метод через config ///

rem 1) Прочитать текущее значение из config.txt
call :ReadConfig GoodbyeZapret_Version_code

set "UPDATED="
rem 2) Если ключ отсутствует — записать текущий код версии
if "%GoodbyeZapret_Version_code%"=="NotFound" (
    call :WriteConfig GoodbyeZapret_Version_code "%Current_GoodbyeZapret_version_code%"
    set "UPDATED=1"
) else (
    rem 3) Если отличается — обновить значение в config.txt
    if /i not "%GoodbyeZapret_Version_code%"=="%Current_GoodbyeZapret_version_code%" (
        rem call :ui_info "Выполняется обновление компонентов. Пожалуйста, подождите..."
        call :WriteConfig GoodbyeZapret_Version_code "%Current_GoodbyeZapret_version_code%"
        if not defined UPDATED set "UPDATED=1"
        rem call :ui_ok "Обновление компонентов завершено."
    )
)

rem 4) Действия после обновления (по аналогии с веткой реестра)
if defined UPDATED (
    if not exist "%ParentDirPath%\tools" mkdir "%ParentDirPath%\tools" >nul 2>&1
)


set "WiFi=Off"
set "CheckURL=https://nordlinepro.xyz/files/GoodbyeZapret_Version"
set "CheckURL_BACKUP=https://mail.ru"
set "DNS_TEST=google.com"

REM --- Combined DNS and internet connectivity check ---
call :ui_info "Проверка DNS и подключения к интернету..."

REM First check DNS resolution
nslookup %DNS_TEST% >nul 2>&1
if errorlevel 1 (
    echo.
    call :ui_err "Ошибка 02: DNS не отвечает или отсутствует доступ к интернету"
    echo   Проверьте подключение и настройки сети.
    set "WiFi=Off"
)

REM --- Если DNS работает, проверяем основной сервер ---

if not defined CURL (
if exist "%ParentDirPath%\tools\curl\curl.exe" (
    set CURL="%ParentDirPath%\tools\curl\curl.exe"
) else (
    set "CURL=curl"
    )
)

call :ui_info "DNS работает. Проверка сервера обновлений (%CheckURL%)..."
%CURL% -4 -s -I --fail --connect-timeout 1 --max-time 2 -o nul "%CheckURL%"
IF %ERRORLEVEL% EQU 0 (
    call :ui_ok "Соединение установлено. Перехожу далее"
    set "UpdaterServerConnect=Yes"
    set "WiFi=On"
) ELSE (
    call :ui_warn "Сервер обновлений недоступен. Проверка общего подключения (%CheckURL_BACKUP%)..."
    %CURL% -4 -s -I --fail --connect-timeout 1 --max-time 3 -o nul "%CheckURL_BACKUP%"
    IF %ERRORLEVEL% EQU 0 (
        call :ui_ok "Интернет доступен"
        call :ui_warn "Но сервер обновлений недоступен (%CheckURL%)"
        set "WiFi=On"
    ) ELSE (
        echo.
        call :ui_err "Ошибка 03: нет доступа к интернету"
        echo   Проверьте подключение и настройки сети.
        set "WiFi=Off"
    )
)

call :ui_info "Выполняю необходимые проверки..."

if not exist "%ParentDirPath%" (
    goto install_screen
)

:RR

REM call :timer_start

REM Инициализируем переменные
set "BatCount=0"
set "sourcePath=%~dp0"

REM --- Запускаем проверку статуса перед изменением размера окна ---
REM set "SilentMode=1"
REM call :CurrentStatus
REM set "SilentMode="
REM ------------------------------------------------------------

set "TotalCheck=Ok"

REM Инициализируем коды цветов
for /F "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do (set "DEL=%%a" & set "COL=%%b")

REM Устанавливаем кодировку UTF-8
chcp 65001 >nul 2>&1

REM === UI helpers: цвета, символы, заголовок ===
goto :UI_HELPERS_END

:ui_init
    if defined ESC exit /b
    if defined COL (set "ESC=%COL%") else (
        for /F "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do (set "DEL=%%a" & set "ESC=%%b")
    )
    REM Получаем сохраненную версию Windows из config
    call :ReadConfig "WinVer"
    set "C_RESET=%ESC%[0m"
    set "C_DIM=%ESC%[90m"
    set "C_INFO=%ESC%[36m"
    set "C_OK=%ESC%[32m"
    set "C_WARN=%ESC%[33m"
    set "C_ERR=%ESC%[31m"
    set "C_TITLE=%ESC%[96m"
    set "C_PRIMARY=%ESC%[94m"
    if "%WinVer%"=="11" (
        set "S_OK=✔"
    ) else (
        set "S_OK=√"  
    )
    set "S_WARN=▲"
    set "S_ERR=✖"
    set "S_INFO=●"
    goto :eof

:ui_info
    call :ui_init
    set "msg=%~1"
    echo  %C_INFO%[ %S_INFO% ]%C_RESET% !msg!
    goto :eof

:ui_ok
    call :ui_init
    set "msg=%~1"
    echo  %C_OK%[ %S_OK% ]%C_RESET% !msg!
    goto :eof

:ui_warn
    call :ui_init
    set "msg=%~1"
    echo  %C_WARN%[ %S_WARN% ]%C_RESET% !msg!
    goto :eof

:ui_err
    call :ui_init
    set "msg=%~1"
    echo  %C_ERR%[ %S_ERR% ]%C_RESET% !msg!
    goto :eof

:ui_hr
    call :ui_init

    chcp 850 >nul 2>&1
    for /f "usebackq tokens=*" %%L in (`powershell -NoProfile -Command "$Host.UI.RawUI.WindowSize.Width"`) do set "W=%%L"
    chcp 65001 >nul 2>&1
    set "line="
    for /l %%i in (1,1,!W!) do set "line=!line!─"
    echo %C_DIM%!line!%C_RESET%
    goto :eof

    :ui_header
    call :ui_init
    setlocal EnableDelayedExpansion
    cls
    if not defined Current_GoodbyeZapret_version ( set "Current_GoodbyeZapret_version=ERROR" )
    if not defined Current_GoodbyeZapret_version_code ( set "Current_GoodbyeZapret_version_code=ERROR" )
    if not defined branch ( set "branch=ERROR" )
    if not defined beta_code ( set "beta_code=ERROR" )
    call :ui_hr
    echo                          %C_RESET%______                ____            _____                         __ 
    echo                         / ____/___  ____  ____/ / /_  __  ____/__  /  ____ _____  ________  / /_
    echo                        / / __/ __ \/ __ \/ __  / __ \/ / / / _ \/ /  / __ `/ __ \/ ___/ _ \/ __/
    echo                       / /_/ / /_/ / /_/ / /_/ / /_/ / /_/ /  __/ /__/ /_/ / /_/ / /  /  __/ /_ 
    echo                       \____/\____/\____/\__,_/_.___/\__, /\___/____/\__,_/ .___/_/   \___/\__/ 
    echo                                                    /____/               /_/
    echo.
    echo  %C_PRIMARY%Версия:%C_RESET% %Current_GoodbyeZapret_version%   %C_PRIMARY%Код:%C_RESET% %Current_GoodbyeZapret_version_code%   %C_PRIMARY%Ветка:%C_RESET% %branch%   %C_PRIMARY%Конфиг:%C_RESET% !GoodbyeZapret_Config!  
    call :ui_hr
    endlocal & goto :eof

:UI_HELPERS_END

:GoodbyeZapret_Menu
REM Инициализируем переменные статуса
set "CheckStatus=WithoutChecked"
set "sourcePath=%~dp0"

REM Устанавливаем значения по умолчанию для конфига GoodbyeZapret
REM set "GoodbyeZapret_Current=Не выбран"
set "GoodbyeZapret_Config=Не выбран"

REM Инициализируем флаг ремонта
set "RepairNeed=No"

REM Обработка процесса ремонта, если необходимо, и доступен WiFi
if /i "!WiFi!"=="On" (
    if /i "!RepairNeed!"=="Yes" (
        cls
        echo.
        echo  Error 03: Critical error. GoodbyeZapret needs to be reinstalled.
        echo  Starting the reinstallation...
        timeout /t 2 >nul

        REM Создаем директорию tools, если она не существует
        if not exist "%ParentDirPath%\tools" (
            md "%ParentDirPath%\tools" >nul 2>&1
        )

        if not exist "%ParentDirPath%\tools\curl\curl.exe" (
            echo  Error: сurl.exe not found
            echo  try downloading it from the update server.
            timeout /t 4 >nul
        )

        REM Download Updater.exe if not present
        if not exist "%ParentDirPath%\tools\Updater.exe" (
            %CURL% -g -L -s -o "%ParentDirPath%\tools\Updater.exe" "https://nordlinepro.xyz/files/Updater.exe" >nul 2>&1
            if not exist "%ParentDirPath%\tools\Updater.exe" (
                echo  Error: Failed to download Updater.exe
                echo  Please check your internet connection and try again.
                timeout /t 3 >nul
                goto GoodbyeZapret_Menu
            )
        )

        timeout /t 2 >nul
        start "" "%ParentDirPath%\tools\Updater.exe"
        exit /b 0
    )
) else if /i "!RepairNeed!"=="Yes" (
    echo.
    echo  Error 04: Critical error. GoodbyeZapret needs to be reinstalled.
    echo  Internet connection required for repair. Please check your connection.
    timeout /t 3 >nul
)

:: Загрузка нового файла GZ_Updater.bat
REM Проверить состояние WiFi перед тем, как продолжить операции обновления
if /i "!WiFi!"=="Off" goto skip_for_wifi

REM Очистить временный файл, если он существует
if exist "%TEMP%\GZ_Updater.bat" (
    del /q /f "%TEMP%\GZ_Updater.bat" >nul 2>&1
    if exist "%TEMP%\GZ_Updater.bat" (
        echo Error: Failed to delete temporary file %TEMP%\GZ_Updater.bat
        timeout /t 2 >nul
    )
)

if not defined CURL (
    set "CURL=curl"
)

%CURL% -4 -s -I --fail --connect-timeout 1 --max-time 1 -o nul "https://nordlinepro.xyz/files/GoodbyeZapret_Version"

IF !ERRORLEVEL! NEQ 0 (
    set "CheckStatus=FileCheckError"
    goto OnFileCheckError
)

REM Скачать файл обновления версии
%CURL% -s -o "%TEMP%\GZ_Updater.bat" "https://nordlinepro.xyz/files/GoodbyeZapret_Version"
if errorlevel 1 (
    echo Error 04: Server error. Failed to connect to GoodbyeZapret update check server
    set "CheckStatus=NoChecked"
    goto OnFileCheckError
)

REM Проверить успешность загрузки файла GZ_Updater.bat
if not exist "%TEMP%\GZ_Updater.bat" (
    echo Error: Failed to download GZ_Updater.bat file
    set "CheckStatus=NoChecked"
    goto OnFileCheckError
)

REM Скачайте Updater.exe, если он не установлен
if not exist "%ParentDirPath%\tools\Updater.exe" (
    REM Создайте директорию tools, если она не существует
    if not exist "%ParentDirPath%\tools" (
        md "%ParentDirPath%\tools" >nul 2>&1
    )
    
    if not defined CURL (
    if exist "%ParentDirPath%\tools\curl\curl.exe" (
        set CURL="%ParentDirPath%\tools\curl\curl.exe"
    ) else (
        set CURL=curl
        )
    )
    %CURL% -g -L -s -o "%ParentDirPath%\tools\Updater.exe" "https://nordlinepro.xyz/files/Updater.exe"
    if not exist "%ParentDirPath%\tools\Updater.exe" (
        echo Error: Failed to download Updater.exe
        set "CheckStatus=NoChecked"
        goto OnFileCheckError
    )
)

REM Проверьте размер файла GZ_Updater.bat
set "FileSize=0"
for %%I in ("%TEMP%\GZ_Updater.bat") do set "FileSize=%%~zI"

if %FileSize% LSS 15 (
    echo Error 05: FileCheck error. File GZ_Updater.bat is corrupted or URL is not available.
    echo ^(Size: %FileSize% bytes^)
    echo.
    del /q "%TEMP%\GZ_Updater.bat" >nul 2>&1
    timeout /t 2 >nul
    set "CheckStatus=FileCheckError"
    goto OnFileCheckError
) else (
    set "CheckStatus=Checked"
)

if "%CheckStatus%"=="FileCheckError" (
    set "Actual_GoodbyeZapret_version=0.0.0"
    set "StatusProject=1"
    goto OnFileCheckError
)

REM Выполнить загруженный файл Updater.bat
call "%TEMP%\GZ_Updater.bat" >nul 2>&1
if errorlevel 1 (
    echo Error 05: Start error. Failed to execute GZ_Updater.bat
    set "CheckStatus=NoChecked"
    goto OnFileCheckError
)

:OnFileCheckError

if "%CheckStatus%"=="FileCheckError" (
    set "Actual_GoodbyeZapret_version=0.0.0"
    set "StatusProject=1"
)

set "UpdateNeed=No"

if "%StatusProject%"=="0" (
    cls
    echo.
    echo  Я был рад быть вам полезным, но пришло время прощаться.
    echo  Проект GoodbyeZapret был закрыт.
    echo.
    REM  GoodbyeZapret
    sc query "GoodbyeZapret" >nul 2>&1
    if !errorlevel! equ 0 (
    net stop "GoodbyeZapret" >nul 2>&1
    sc delete "GoodbyeZapret" >nul 2>&1
    )

    
    REM  winws.exe
    tasklist /FI "IMAGENAME eq winws.exe" 2>NUL | find /I /N "winws.exe" >NUL
    if not errorlevel 1 (
        taskkill /F /IM winws.exe >nul 2>&1
        taskkill /F /IM winws2.exe >nul 2>&1
    )
    
    REM  WinDivert
    sc query "WinDivert" >nul 2>&1
    if %errorlevel% equ 0 (
        net stop "WinDivert" >nul 2>&1
        sc delete "WinDivert" >nul 2>&1
    )
    
    REM  monkey
    sc query "monkey" >nul 2>&1
    if %errorlevel% equ 0 (
        net stop "monkey" >nul 2>&1
        sc delete "monkey" >nul 2>&1
    )
    
    REM Clean up registry and directories 
    reg delete "HKCU\Software\ALFiX inc.\GoodbyeZapret" /f >nul 2>&1
    if exist "%ParentDirPath%\configs" rd /s /q "%ParentDirPath%\configs" >nul 2>&1
    if exist "%ParentDirPath%\bin" rd /s /q "%ParentDirPath%\bin" >nul 2>&1
    if exist "%ParentDirPath%\lists" rd /s /q "%ParentDirPath%\lists" >nul 2>&1
    if exist "%ParentDirPath%\tools" rd /s /q "%ParentDirPath%\tools" >nul 2>&1
    
    timeout /t 7 >nul 2>&1
    exit /b
)

REM Проверяем, изменилась ли версия
if not "%CheckStatus%"=="FileCheckError" (
    if defined Actual_GoodbyeZapret_version_code (
        if defined Current_GoodbyeZapret_version_code (
            echo "%Actual_GoodbyeZapret_version_code%" | findstr /i "%Current_GoodbyeZapret_version_code%" >nul
            if errorlevel 1 (
                set "UpdateNeed=Yes"
            ) else (
                set "UpdateNeed=No"
                set "VersionFound=1"
            )
        ) else (
            set "UpdateNeed=No"
        )
    ) else (
        set "UpdateNeed=No"
    )
)

:skip_for_wifi

REM Проверяем, существует ли GoodbyeZapretTray.exe перед запуском
if exist "%ParentDirPath%\tools\tray\GoodbyeZapretTray.exe" (
    REM Завершаем процесс GoodbyeZapretTray.exe, если он уже запущен
    tasklist /FI "IMAGENAME eq GoodbyeZapretTray.exe" 2>NUL | find /I /N "GoodbyeZapretTray.exe" >NUL
    if !errorlevel! equ 1 (
        REM GoodbyeZapretTray.exe не запущен, ничего делать не нужно
    ) else (
        taskkill /F /IM GoodbyeZapretTray.exe >nul 2>&1
        if exist "%ParentDirPath%\tools\tray\goodbyezapret_tray.log" (
            del /F /Q "%ParentDirPath%\tools\tray\goodbyezapret_tray.log" >nul
        )
        timeout /t 1 >nul
    )
    start "" "%ParentDirPath%\tools\tray\GoodbyeZapretTray.exe"
)

title GoodbyeZapret - Launcher

REM Попробуйте прочитать значение из config.txt
call :ReadConfig GoodbyeZapret_Config
if not defined GoodbyeZapret_Config (
    set "GoodbyeZapret_Config=Not found"
)

rem Попробовать считать значение из config
call :ReadConfig GoodbyeZapret_Version

if "%GoodbyeZapret_Version%"=="NotFound" (
    set "GoodbyeZapret_Version_OLD=NotFound"
) else (
    set "GoodbyeZapret_Version_OLD=%GoodbyeZapret_Version%"
)

goto :end_GoodbyeZapret_Version_OLD

:end_GoodbyeZapret_Version_OLD

REM Проверяем, была ли ранее определена переменная Current_GoodbyeZapret_version
if not defined Current_GoodbyeZapret_version (
    REM Если переменная не определена, устанавливаем значения по умолчанию. Независимо от состояния Wi-Fi.
    set "Current_GoodbyeZapret_version=NotFound"
    set "Actual_GoodbyeZapret_version=0.0.0"
    set "UpdateNeed=No"

    REM Теперь проверяем, почему переменная не была определена. Если Wi-Fi НЕ выключен, значит, произошла ошибка чтения из сети.
    if /I not "%WiFi%"=="off" (
        echo.
        echo   Error 06: Read error. Failed to read value GoodbyeZapret_Version
        timeout /t 2 >nul
    )
)

REM Проверьте сервис GoodbyeZapret и получите текущую конфигурацию
reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\GoodbyeZapret" /v Description >nul 2>&1
if %errorlevel% equ 0 (
    for /f "tokens=2*" %%a in ('reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\GoodbyeZapret" /v "Description" 2^>nul ^| find /i "Description"') do (
        set "GoodbyeZapret_Current=%%b"
    )
)

if /i "%GoodbyeZapret_Config%" neq "NotFound" if /i not "%GoodbyeZapret_Config%"=="%GoodbyeZapret_Current%" call :WriteConfig GoodbyeZapret_Config "%GoodbyeZapret_Current%"

REM Update version in registry if defined
 if defined Current_GoodbyeZapret_version (
    call :WriteConfig GoodbyeZapret_Version "%Current_GoodbyeZapret_version%"
 )

:GZ_loading_process
REM set "SilentMode=1"
REM call :CurrentStatus
REM set "SilentMode="

if "%UpdateNeedShowScreen%"=="1" (
    goto MainMenu
) else (
    if "%UpdateNeed%"=="Yes" (
        set "UpdateNeedShowScreen=1"
        goto Update_Need_screen
    )
)


:MainMenu
cls
call :ui_info "Загружаю интерфейс..."
REM ------ New: run quick problem check silently ------
REM ----------------------------------------------------
:MainMenu_without_ui_info
REM call :ResizeMenuWindow
set /a MainMenuLines=41
if /i "%WiFi%"=="Off" set /a MainMenuLines+=1
if "%CheckStatus%"=="FileCheckError" set /a MainMenuLines+=1
mode con: cols=92 lines=%MainMenuLines%
REM Check for last working config in registry

call :ReadConfig GoodbyeZapret_Config
if "%GoodbyeZapret_Config%"=="NotFound" (
    REM Если переменная не найдена, установите значение по умолчанию
    set "GoodbyeZapret_Config=Не выбран"
)

REM Check GoodbyeZapret service status
sc query "GoodbyeZapret" >nul 2>&1
if %errorlevel% equ 0 (
    set "GoodbyeZapretStart=Yes"
) else (
    set "GoodbyeZapretStart=No"
)

REM Check Winws process status
set "WinwsStart=No"
for %%P in (winws.exe winws2.exe) do (
    tasklist /FI "IMAGENAME eq %%P" 2>nul | find /I "%%P" >nul && set "WinwsStart=Yes"
)

REM Проверка запущенных служб WinDivert
set "WinDivertStart=No"

for %%S in ("WinDivert" "WinDivert14" "monkey") do (
    sc query %%~S 2>nul | find /I "RUNNING" >nul
    if not errorlevel 1 (
        set "WinDivertStart=Yes"
    )
)

REM Count running services/processes
set "YesCount=0"
if "%GoodbyeZapretStart%"=="Yes" set /a YesCount+=1
if "%WinwsStart%"=="Yes" set /a YesCount+=1
if "%WinDivertStart%"=="Yes" set /a YesCount+=1


REM Display status based on running count
if %YesCount% equ 3 (
    REM запущены все сервисы
    cls
    echo.
    echo           %COL%[92m  ______                ____            _____                         __ 
) else if %YesCount% equ 2 (
    REM запущены Winws и WinDivert
    cls
    echo.
    echo           %COL%[33m  ______                ____            _____                         __ 
) else (
    REM запущен только GoodbyeZapret
    cls
    echo.
    echo           %COL%[90m  ______                ____            _____                         __ 
)


REM Set window title
if not defined Current_GoodbyeZapret_version (
    if /i "%branch%"=="beta" (
        title GoodbyeZapret - Launcher - бета версия %beta_code%
    ) else if /i "%branch%"=="alpha" (
        title GoodbyeZapret - Launcher - альфа версия
    ) else (
        title GoodbyeZapret - Launcher
    )
) else (
    if /i "%branch%"=="beta" (
        title GoodbyeZapret - Launcher v%Current_GoodbyeZapret_version% бета %beta_code%
    ) else if /i "%branch%"=="alpha" (
        title GoodbyeZapret - Launcher v%Current_GoodbyeZapret_version% альфа
    ) else (
        title GoodbyeZapret - Launcher v%Current_GoodbyeZapret_version%
    )
)


echo            / ____/___  ____  ____/ / /_  __  ____/__  /  ____ _____  ________  / /_
echo           / / __/ __ \/ __ \/ __  / __ \/ / / / _ \/ /  / __ `/ __ \/ ___/ _ \/ __/
echo          / /_/ / /_/ / /_/ / /_/ / /_/ / /_/ /  __/ /__/ /_/ / /_/ / /  /  __/ /_
echo          \____/\____/\____/\__,_/_.___/\__, /\___/____/\__,_/ .___/_/   \___/\__/

if /i "%branch%"=="beta" (
    echo                                        /____/  бета версия  /_/
    echo.
) else if /i "%branch%"=="alpha" (
    echo                                        /____/ альфа версия  /_/
    echo.
) else (
    echo                                        /____/              /_/
    echo.
)



REM call :timer_end


REM Check internet connection and file status
if /i "%WiFi%"=="Off" (
    echo                            %COL%[90mОшибка: Нет подключения к интернету%COL%[37m
) else if "%CheckStatus%"=="FileCheckError" (
    echo                  %COL%[90mОшибка: Нет связи с сервером - возможны проблемы в работе%COL%[37m
) else if not "%CheckStatus%"=="Checked" if not "%CheckStatus%"=="WithoutChecked" (
    echo                %COL%[90mОшибка: Не удалось проверить файлы - возможны проблемы в работе%COL%[37m
) else (
    echo.
)

REM ------ New: warn user if system problems detected ------
REM if "%TotalCheck%"=="Problem" (
REM     echo                         %COL%[90mВозможна нестабильная работа GoodbyeZapret
REM     echo             %COL%[90m ────────────────────────────────────────────────────────────────── %COL%[37m
REM ) else (
    echo             %COL%[90m ────────────────────────────────────────────────────────────────── %COL%[37m
    echo.
REM )
echo.
echo.
echo.
echo.
echo.
echo                               %COL%[96m^[ 1 ^]%COL%[37m Состояние GoodbyeZapret
echo.
echo                               %COL%[96m^[ 2 ^]%COL%[37m Конфигуратор стратегий
echo.
echo                               %COL%[96m^[ 3 ^]%COL%[37m Выбор готового конфига
echo.
echo                               %COL%[96m^[ 4 ^]%COL%[37m Доп. настройки обхода
echo.
echo                               %COL%[96m^[ 5 ^]%COL%[37m Проверить доступ к CDN 
echo.
echo                               %COL%[96m^[ 6 ^]%COL%[37m Открыть инструкцию
echo.
echo                               %COL%[96m^[ 7 ^]%COL%[37m Прокси для тг
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.

REM Display separator line
echo             %COL%[90m ────────────────────────────────────────────────────────────────── %COL%[37m
echo                             %COL%[90mВведите %COL%[96m^[ номер ^]%COL%[90m и нажмите %COL%[96mEnter%COL%[90m 
echo.
set /p "choice=%DEL%                                           %COL%[90m:> "

REM Handle user input with case-insensitive matching
if /i "%choice%"=="1" goto CurrentStatus 
if /i "%choice%"=="2" goto ConfiguratorMenu
if /i "%choice%"=="3" goto ConfigSelectorMenu_without_ui_info
if /i "%choice%"=="4" goto MenuBypassSettings
if /i "%choice%"=="5" Start https://hyperion-cs.github.io/dpi-checkers/ru/tcp-16-20
if /i "%choice%"=="6" goto OpenInstructions
if /i "%choice%"=="7" goto TgWsProxyMenu
if /i "%choice%"=="net" ( chcp 850 >nul 2>&1
    powershell -Command "Start-Process '%ParentDirPath%\tools\network_analyzer\netprobe.exe' -Verb RunAs"
    chcp 65001 >nul 2>&1
)
goto MainMenu

:MenuBypassSettings
REM call :ResizeMenuWindow
title GoodbyeZapret - Дополнительные настройки обхода
mode con: cols=92 lines=41
REM Check for last working config in registry

set "hostspath=%SystemRoot%\System32\drivers\etc\hosts"
set "tempfile=%temp%\hosts.tmp"
findstr /c:"### Discord Finland Media Servers BEGIN" "%hostspath%" >nul
if not errorlevel 1 (
    set "FinlandDiscordHost=On"
) else (
    set "FinlandDiscordHost=Off"
)

findstr /c:"### Twitch Servers BEGIN" "%hostspath%" >nul
if not errorlevel 1 (
    set "TwitchHost=On"
) else (
    set "TwitchHost=Off"
)

findstr /c:"### YouTube TCP Servers BEGIN" "%hostspath%" >nul
if not errorlevel 1 (
    set "YoutubeHost=On"
) else (
    set "YoutubeHost=Off"
)


REM Display status based on running count
if %YesCount% equ 3 (
    REM запущены все сервисы
    cls
    echo.
    echo           %COL%[92m  ______                ____            _____                         __ 
) else if %YesCount% equ 2 (
    REM запущены Winws и WinDivert
    cls
    echo.
    echo           %COL%[33m  ______                ____            _____                         __ 
) else (
    REM запущен только GoodbyeZapret
    cls
    echo.
    echo           %COL%[90m  ______                ____            _____                         __ 
)


echo            / ____/___  ____  ____/ / /_  __  ____/__  /  ____ _____  ________  / /_
echo           / / __/ __ \/ __ \/ __  / __ \/ / / / _ \/ /  / __ `/ __ \/ ___/ _ \/ __/
echo          / /_/ / /_/ / /_/ / /_/ / /_/ / /_/ /  __/ /__/ /_/ / /_/ / /  /  __/ /_
echo          \____/\____/\____/\__,_/_.___/\__, /\___/____/\__,_/ .___/_/   \___/\__/

if /i "%branch%"=="beta" (
    echo                                        /____/  бета версия  /_/
    echo.
) else if /i "%branch%"=="alpha" (
    echo                                        /____/ альфа версия  /_/
    echo.
) else (
    echo                                        /____/              /_/
    echo.
)

echo             %COL%[90m ────────────────────────────────────────────────────────────────── %COL%[37m

call "%USERPROFILE%\AppData\Roaming\GoodbyeZapret\ports.bat"

if defined tcp_portsV (
    if not defined tcp_ports set "tcp_ports=%tcp_portsV%"
) else (
    if not defined tcp_ports set "tcp_ports=80,443,1080,2053,2083,2087,2096,6568,8443"
)

if defined udp_portsV (
    if not defined udp_ports set "udp_ports=%udp_portsV%"
) else (
    if not defined udp_ports set "udp_ports=80,443,1024-65535,4"
)

for /f "tokens=2*" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v "CDN_BypassLevel" 2^>nul ^| findstr /i "CDN_BypassLevel"') do (
    set "CDN_BypassLevel=%%B"
)

echo.
echo.
echo                    %COL%[96m^[ 1 ^]%COL%[37m Уровень обхода CDN               ^(%COL%[96m%CDN_BypassLevel%%COL%[37m^)
echo.
echo                    %COL%[96m^[ 2 ^]%COL%[37m Host Обход Discord + Fin. Voice   ^(%COL%[96m%FinlandDiscordHost%%COL%[37m^)
echo.
echo                    %COL%[96m^[ 3 ^]%COL%[37m Host Обход twitch                 ^(%COL%[96m%TwitchHost%%COL%[37m^)
echo.
echo                    %COL%[96m^[ 4 ^]%COL%[37m Host Обход YouTube                ^(%COL%[96m%YoutubeHost%%COL%[37m^)
echo.
echo                    %COL%[96m^[ 5 ^]%COL%[37m TCP порты обхода:
echo                    %COL%[92m%tcp_ports%
echo.
echo                    %COL%[96m^[ 6 ^]%COL%[37m UDP порты обхода:
echo                    %COL%[92m%udp_ports%
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.

REM Display separator line
REM echo             %COL%[90m ────────────────────────────────────────────────────────────────── %COL%[37m
echo                    %COL%[90mВведите %COL%[96m^[ номер ^]%COL%[90m или %COL%[96m^[ B ^]%COL%[90m для выхода в главное меню
echo.
set /p "choice=%DEL%                                           %COL%[90m:> "

REM Handle user input with case-insensitive matching
if /i "%choice%"=="1" goto CDN_BypassLevelSelector
if /i "%choice%"=="2" goto FinlandDiscordHostSelector
if /i "%choice%"=="3" goto TwitchHostSelector
if /i "%choice%"=="4" goto YoutubeHostsSelector

if /i "%choice%"=="B" goto MainMenu_without_ui_info
if /i "%choice%"=="и" goto MainMenu_without_ui_info

:: Проверки ввода с использованием полученных лимитов
if "%choice%"=="5" (
    set /p tcp_ports="%DEL%   Введите новые TCP порты: "
    REM Записываем новое значение в реестр (системные переменные)

    reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v "tcp_ports" /t REG_SZ /d "!tcp_ports!" /f >nul

    if defined tcp_ports (
        call :WriteConfig tcp_ports "%tcp_ports%"
    ) else (
        echo ^[ERROR^] tcp_ports не определен
    )
    goto MenuBypassSettings
)

:: Проверки ввода с использованием полученных лимитов
if "%choice%"=="6" (
    set /p udp_ports="%DEL%   Введите новые UDP порты: "
    REM Записываем новое значение в реестр (системные переменные)

    reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v "udp_ports" /t REG_SZ /d "!udp_ports!" /f >nul

    if defined udp_ports (
        call :WriteConfig udp_ports "%udp_ports%"
    ) else (
        echo ^[ERROR^] udp_ports не определен
    )
    goto MenuBypassSettings
)

goto MenuBypassSettings


:ConfigSelectorMenu
call :ui_info "Загружаю конфиги..."
REM ------ New: run quick problem check silently ------
REM ----------------------------------------------------
:ConfigSelectorMenu_without_ui_info
set "PanelBack=ConfigSelectorMenu"
call :ResizeMenuWindow
REM Check for last working config in registry
call :ReadConfig GoodbyeZapret_LastWorkConfig
if "%GoodbyeZapret_LastWorkConfig%"=="NotFound" (
    set "GoodbyeZapret_LastWork=none"
) else (
    rem Обрезать последние 4 символа: %var:~0,-4%
    set "GoodbyeZapret_LastWork=%GoodbyeZapret_LastWorkConfig:~0,-4%"
)

call :ReadConfig GoodbyeZapret_Config
if "%GoodbyeZapret_Config%"=="NotFound" (
    REM Если переменная не найдена, установите значение по умолчанию
    set "GoodbyeZapret_Config=Не выбран"
)

REM Check GoodbyeZapret service status
sc query "GoodbyeZapret" >nul 2>&1
if %errorlevel% equ 0 (
    set "GoodbyeZapretStart=Yes"
) else (
    set "GoodbyeZapretStart=No"
)

REM Check Winws process status
set "WinwsStart=No"
for %%P in (winws.exe winws2.exe) do (
    tasklist /FI "IMAGENAME eq %%P" 2>nul | find /I "%%P" >nul && set "WinwsStart=Yes"
)

REM Проверка запущенных служб WinDivert
set "WinDivertStart=No"

for %%S in ("WinDivert" "WinDivert14" "monkey") do (
    sc query %%~S 2>nul | find /I "RUNNING" >nul
    if not errorlevel 1 (
        set "WinDivertStart=Yes"
        goto :DoneStartCheck
    )
)

:DoneStartCheck
REM Count running services/processes
set "YesCount=0"
if "%GoodbyeZapretStart%"=="Yes" set /a YesCount+=1
if "%WinwsStart%"=="Yes" set /a YesCount+=1
if "%WinDivertStart%"=="Yes" set /a YesCount+=1


REM Display status based on running count
if %YesCount% equ 3 (
    REM запущены все сервисы
    cls
    echo.
    echo           %COL%[92m  ______                ____            _____                         __ 
) else if %YesCount% equ 2 (
    REM запущены Winws и WinDivert
    cls
    echo.
    echo           %COL%[33m  ______                ____            _____                         __ 
) else (
    REM запущен только GoodbyeZapret
    cls
    echo.
    echo           %COL%[90m  ______                ____            _____                         __ 
)


REM Set window title
if not defined Current_GoodbyeZapret_version (
    if /i "%branch%"=="beta" (
        title GoodbyeZapret - Launcher - бета версия %beta_code%
    ) else (
        title GoodbyeZapret - Launcher
    )
) else (
    if /i "%branch%"=="beta" (
        title GoodbyeZapret - Launcher v%Current_GoodbyeZapret_version% бета %beta_code% 
    ) else (
        title GoodbyeZapret - Launcher v%Current_GoodbyeZapret_version%
    )
)

echo            / ____/___  ____  ____/ / /_  __  ____/__  /  ____ _____  ________  / /_
echo           / / __/ __ \/ __ \/ __  / __ \/ / / / _ \/ /  / __ `/ __ \/ ___/ _ \/ __/
echo          / /_/ / /_/ / /_/ / /_/ / /_/ / /_/ /  __/ /__/ /_/ / /_/ / /  /  __/ /_ 
echo          \____/\____/\____/\__,_/_.___/\__, /\___/____/\__,_/ .___/_/   \___/\__/ 

if /i "%branch%"=="beta" (
    echo                                       /____/  бета версия  /_/ 
    echo.
    echo             %COL%[90mГотовые конфиги менее эффективны. Используйте конфигуратор стратегий %COL%[37m
) else (
    echo                                       /____/               /_/
    echo.
    echo             %COL%[90mГотовые конфиги менее эффективны. Используйте конфигуратор стратегий %COL%[37m
)

REM call :timer_end

REM ---------------------------------------------------------

REM Display separator line
echo             %COL%[90m ────────────────────────────────────────────────────────────────── %COL%[37m

echo                  %COL%[36mКонфиги:
echo.
set "choice="
set "counter=0"

REM -- Ensure pagination variables exist --
if not defined Page set "Page=1"
if not defined PageSize set "PageSize=23"
REM ---------------------------------------

REM ---------- Pagination indices ----------
set /a StartIndex=(Page-1)*PageSize+1
set /a EndIndex=StartIndex+PageSize-1

if not defined ParentDirPath (
:: Get the parent directory path more reliably
for /f "delims=" %%A in ('powershell -NoProfile -Command "Split-Path -Parent '%~f0'"') do set "ParentDirPath=%%A"  
)

if not exist "%ParentDirPath%\configs\Preset" (
    Echo  ОШИБКА - "%ParentDirPath%\configs\Preset"
    pause >nul
)

set "hasActiveOrStarted=0"
set /a counter=0

if defined ConfigListMappedCount (
    for /L %%I in (1,1,!ConfigListMappedCount!) do set "file%%I="
)
set "ConfigListMappedCount=0"

REM === Получаем список конфигов с приоритетом .txt ====================
if not defined ConfigListFile (
    echo.
    echo  ОШИБКА - не удалось собрать список конфигов.
    pause >nul
    goto MainMenu
)
if not exist "%ConfigListFile%" (
    echo.
    echo  ОШИБКА - конфиги не найдены.
    echo  Папка конфигов = %ParentDirPath%\configs
    pause >nul
    goto MainMenu
)
if "!ConfigListCount!"=="0" (
    echo.
    echo  ОШИБКА - конфиги не найдены.
    echo  Папка конфигов = %ParentDirPath%\configs
    pause >nul
    goto MainMenu
)
REM === Проверка активного конфига ================================
for /f "usebackq tokens=1* delims=|" %%A in ("%ConfigListFile%") do (
    for %%P in ("%%B") do (
        if /i "%%~nP"=="%GoodbyeZapret_Config%" set "hasActiveOrStarted=1"
    )
)

REM === Вывод ======================================================
for /f "usebackq tokens=1* delims=|" %%A in ("%ConfigListFile%") do (
    set /a counter+=1
    set "ConfigLabel=%%A"
    set "ConfigRel=%%B"
    for %%P in ("%%B") do (
        set "ConfigName=%%~nP"
        set "ConfigFull=%%~nxP"
    )

    set "StatusText="
    set "StatusColor=%COL%[37m"

    if /i "!ConfigName!"=="%GoodbyeZapret_Config%" (
        set "StatusText=[Текущий]"
        set "StatusColor=%COL%[92m"
    ) else if /i "!ConfigName!"=="!GoodbyeZapret_LastWork!" if "!hasActiveOrStarted!"=="0" (
        set "StatusText=[Работал лучше других]"
        set "StatusColor=%COL%[93m"
    )

    if !counter! lss 10 (set "Pad= ") else set "Pad="

    if !counter! geq !StartIndex! if !counter! leq !EndIndex! (
        if defined StatusText (
            echo                  !Pad!%COL%[36m!counter!. %COL%[36m!ConfigLabel! !StatusColor!!StatusText!
        ) else (
            echo                  !Pad!%COL%[36m!counter!. %COL%[37m!ConfigLabel!
        )
    )

    set "file!counter!=!ConfigRel!"
)
set "ConfigListMappedCount=!counter!"

REM ---------------------------------------------------------------------------------

set /a "lastChoice=counter"
set /a TotalPages=(counter+PageSize-1)/PageSize
if %Page% gtr %TotalPages% set /a Page=%TotalPages%

REM Display update notification if available
if "%UpdateNeed%"=="Yes" (
    if defined Current_GoodbyeZapret_version (
        title GoodbyeZapret v%Current_GoodbyeZapret_version% - ДОСТУПНО ОБНОВЛЕНИЕ
    ) else (
        title GoodbyeZapret - ДОСТУПНО ОБНОВЛЕНИЕ
    )
)

echo             %COL%[90m ────────────────────────────────────────────────────────────────── %COL%[37m
echo                  %COL%[36mДействия:
echo.

REM Display different menu options based on current service status
if "%GoodbyeZapret_Config%"=="Не выбран" (
    echo                  %COL%[36m^[1-!counter!s^] %COL%[92mЗапустить конфиг
    echo                   %COL%[36m^[1-!counter!^] %COL%[92mУстановить конфиг в автозапуск
) else (
    echo                    %COL%[36m^[ D ^] %COL%[91mУдалить конфиг из автозапуска
    echo                    %COL%[36m^[ R ^] %COL%[37mБыстрый перезапуск конфига
)
echo                    %COL%[36m^[ A ^] %COL%[92mАвто-подбор и установка конфига

REM ---- Pagination options ----
if %TotalPages% gtr 1 (
    echo.
    if %Page% lss %TotalPages% echo                    %COL%[36m^[ N ^] %COL%[37mСледующая страница с конфигами
    if %Page% gtr 1 echo                    %COL%[36m^[ B ^] %COL%[37mПредыдущая страница
    if %Page% equ 1 echo                    %COL%[36m^[ B ^] %COL%[37mВернуться в главное меню
) else (
    echo                    %COL%[36m^[ B ^] %COL%[37mВернуться в главное меню
)
REM ----------------------------
echo.
echo.
echo                              %COL%[90mВведите %COL%[96m^[ номер ^]%COL%[90m или %COL%[96m^[ букву ^]%COL%[90m
echo.
set /p "choice=%DEL%                                           %COL%[90m:> "
set "choice=!choice: =!"

REM Handle user input with case-insensitive matching
if /i "!choice!"=="D" goto remove_service
if /i "!choice!"=="в" goto remove_service

if /i "!choice!"=="R" goto QuickRestart
if /i "!choice!"=="к" goto QuickRestart

if /i "!choice!"=="S" goto CurrentStatus
if /i "!choice!"=="ы" goto CurrentStatus

if /i "!choice!"=="RR" goto RR

if /i "!choice!"=="A" goto ReadyConfigAutoPicker
if /i "!choice!"=="ф" goto ReadyConfigAutoPicker

REM --- Pagination input handling ---
if /i "!choice!"=="N" (
    set /a Page+=1
    goto ConfigSelectorMenu_without_ui_info
)
if /i "!choice!"=="т" (
    set /a Page+=1
    goto ConfigSelectorMenu_without_ui_info
)
if /i "!choice!"=="B" (
    if %Page% equ 1 goto MainMenu_without_ui_info
    if %Page% gtr 1 set /a Page-=1
    goto ConfigSelectorMenu_without_ui_info
)
if /i "!choice!"=="и" (
    if %Page% equ 1 goto MainMenu_without_ui_info
    if %Page% gtr 1 set /a Page-=1
    goto ConfigSelectorMenu_without_ui_info
)
REM ---------------------------------

REM Handle update option only if update is available
if "%UpdateNeed%"=="Yes" (
    if /i "!choice!"=="UD" goto Update_Need_screen
)

goto ReadyConfigAutoPicker_EndLabel

:ReadyConfigAutoPicker
cls
title GoodbyeZapret - Авто-подбор готового конфига
echo.
echo  %COL%[36mАвто-подбор готового конфига%COL%[37m
echo  %COL%[90mЛаунчер будет запускать готовые конфиги по очереди и проверять доступность доменов.%COL%[37m
echo.

if not defined ConfigListFile (
    call :EnsureConfigListCache
)
if not defined ConfigListFile goto ReadyConfigAutoNoList
if not exist "%ConfigListFile%" goto ReadyConfigAutoNoList
if "!ConfigListCount!"=="0" goto ReadyConfigAutoNoList

set "ReadyAutoHadService=0"
sc query "GoodbyeZapret" >nul 2>&1
if not errorlevel 1 set "ReadyAutoHadService=1"

set "ReadyAutoFound=0"
set /a ReadyAutoIndex=0
for /f "usebackq tokens=1* delims=|" %%A in ("%ConfigListFile%") do (
    if "!ReadyAutoFound!"=="0" (
        set /a ReadyAutoIndex+=1
        set "ReadyAutoLabel=%%A"
        set "ReadyAutoRel=%%B"
        for %%P in ("%%B") do (
            set "ReadyAutoFile=%%~nxP"
            set "ReadyAutoExt=%%~xP"
        )

        cls
        title GoodbyeZapret - Авто-подбор готового конфига
        echo.
        echo  %COL%[36mАвто-подбор готового конфига%COL%[37m
        echo  %COL%[90mЛаунчер будет запускать готовые конфиги по очереди и проверять доступность доменов.%COL%[37m
        echo.
        echo  %COL%[90m────────────────────────────────────────────────────────%COL%[37m
        echo  %COL%[96m[!ReadyAutoIndex!/!ConfigListCount!]%COL%[37m !ReadyAutoLabel!
        call :ReadyConfigAutoStopRunning

        if /I "!ReadyAutoExt!"==".txt" (
            call :StartTextPreset "%ParentDirPath%\configs\!ReadyAutoRel!"
        ) else (
            start "" "%ParentDirPath%\configs\!ReadyAutoRel!"
        )

        set "ReadyAutoWait=8"
        if /I "!ReadyAutoExt!"==".txt" set "ReadyAutoWait=15"
        call :WaitForBypassProcess !ReadyAutoWait!
        if errorlevel 1 (
            echo  %COL%[91m[FAIL]%COL%[37m Процесс обхода не запустился.
        ) else (
            call :ReadyConfigAutoCheck "!ReadyAutoFile!"
            if errorlevel 1 (
                echo  %COL%[91m[FAIL]%COL%[37m Проверка доменов не прошла.
            ) else (
                set "ReadyAutoFound=1"
                set "batRel=!ReadyAutoRel!"
                set "batFile=!ReadyAutoFile!"
                set "CfgExt=!ReadyAutoExt!"
            )
        )
    )
)

if "!ReadyAutoFound!"=="1" (
    echo.
    echo  %COL%[92m[OK]%COL%[37m Найден рабочий конфиг: %COL%[92m!batFile!%COL%[37m
    call :ReadyConfigAutoStopRunning
    call :remove_service_before_installing
    if errorlevel 1 goto :end
    call :install_GZ_service
)

call :ReadyConfigAutoStopRunning
if "!ReadyAutoHadService!"=="1" sc start "GoodbyeZapret" >nul 2>&1
echo.
echo  %COL%[91m[WARN]%COL%[37m Рабочий готовый конфиг не найден.
echo  %COL%[90mНажмите любую клавишу чтобы вернуться назад.%COL%[37m
pause >nul
goto ConfigSelectorMenu_without_ui_info

:ReadyConfigAutoNoList
echo  %COL%[91m[WARN]%COL%[37m Список конфигов не найден.
echo  %COL%[90mНажмите любую клавишу чтобы вернуться назад.%COL%[37m
pause >nul
goto ConfigSelectorMenu_without_ui_info

:ReadyConfigAutoPicker_EndLabel

REM Return to main menu if no input provided
if "!choice!"=="" goto MainMenu

REM Handle configuration file selection and validation
set "ChoiceSuffix=!choice:~-1!"
set "ChoiceNumber=!choice:~0,-1!"
if /i "!ChoiceSuffix!"=="ы" set "ChoiceSuffix=s"

if /i "!ChoiceSuffix!"=="s" (
    REM Manual start mode - open config file in explorer
    echo(!ChoiceNumber!| findstr /r "^[0-9][0-9]*$" >nul
    if errorlevel 1 (
        echo Неверный выбор. Пожалуйста, попробуйте снова.
        goto MainMenu
    )
    for %%N in (!ChoiceNumber!) do call set "batRel=%%file%%N%%"
    if defined batRel for %%A in ("!batRel!") do set "batFile=%%~nxA"

    if defined batRel (
        for %%A in ("!batRel!") do set "CfgExt=%%~xA"
        if /I "!CfgExt!"==".txt" (
            call :StartTextPreset "%ParentDirPath%\configs\!batRel!"
        ) else (
            start "" "%ParentDirPath%\configs\!batRel!"
        )
        goto :end
    ) else (
        echo Неверный выбор. Пожалуйста, попробуйте снова.
        goto MainMenu
    )
) else (
    REM Service installation mode
    echo(!choice!| findstr /r "^[0-9][0-9]*$" >nul
    if errorlevel 1 (
        echo Неверный выбор. Пожалуйста, попробуйте снова.
        goto MainMenu
    )
    for %%N in (!choice!) do call set "batRel=%%file%%N%%"
    if defined batRel for %%A in ("!batRel!") do set "batFile=%%~nxA"
)

REM Initialize color variables if not already set
if not defined COL (
    for /F "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do (set "DEL=%%a" & set "COL=%%b")
)

REM Validate configuration file selection
if not defined batFile (
    echo Неверный выбор. Пожалуйста, попробуйте снова.
    goto MainMenu
)

REM Check if selected config file exists
if not exist "%ParentDirPath%\configs\!batRel!" (
    echo Ошибка: Файл конфига !batRel! не найден.
    echo Пожалуйста, попробуйте снова.
    goto MainMenu
)

REM Confirm installation with user
cls
echo %COL%[97m
echo.
echo   Подтвердите установку %COL%[36m!batFile!%COL%[97m в службу GoodbyeZapret
echo  %COL%[90m Нажмите любую клавишу для подтверждения... %COL%[37m
echo.
pause >nul 2>&1

REM Clean up existing service before installing new one
call :remove_service_before_installing
if errorlevel 1 goto :end
call :install_GZ_service

:install_GZ_service
cls
call :ui_init
call :ui_hr
echo   %C_TITLE%Установка службы GoodbyeZapret !batRel! %C_RESET%
call :ui_hr
echo.

if exist "%ParentDirPath%\tools\tray\GoodbyeZapretTray.exe" (
    chcp 850 >nul 2>&1
    powershell -NoProfile -ExecutionPolicy Bypass -File "%ParentDirPath%\tools\RegisterTrayAutostart.ps1" -ProjectDir "%ParentDirPath%" > "%TEMP%\GoodbyeZapretTrayTask.log" 2>&1
    if errorlevel 1 (
        call :ui_warn "Не удалось настроить автозапуск Tray через планировщик."
        call :ui_warn "Проверьте запуск Launcher от имени администратора."
        call :ui_warn "Лог: %TEMP%\GoodbyeZapretTrayTask.log"
    )
    chcp 65001 >nul 2>&1
)

call :ui_info "Устанавливаю !batFile! в службу GoodbyeZapret..."
for %%A in ("!batRel!") do (
    set "BaseCfg=%%~nA"
    set "CfgExt=%%~xA"
)

if /I "!CfgExt!"==".txt" (
    chcp 850 >nul 2>&1
    powershell -NoProfile -ExecutionPolicy Bypass -File "%ParentDirPath%\tools\service\BuildGoodbyeZapretService.ps1" -ProjectDir "%ParentDirPath%" >nul 2>&1
    chcp 65001 >nul 2>&1
    if errorlevel 1 (
        set "ServiceCreateError=1"
    ) else (
        sc create "GoodbyeZapret" binPath= "\"%ParentDirPath%\tools\service\GoodbyeZapretService.exe\" --preset \"%ParentDirPath%\configs\!batRel!\" --project-dir \"%ParentDirPath%\"" >nul 2>&1
        set "ServiceCreateError=!errorlevel!"
    )
) else (
    sc create "GoodbyeZapret" binPath= "cmd.exe /c \"\"%ParentDirPath%\configs\!batRel!\"\"" >nul 2>&1
    set "ServiceCreateError=!errorlevel!"
)

if not "!ServiceCreateError!"=="0" (
    call :ui_err "Не удалось создать службу GoodbyeZapret ^(код !ServiceCreateError!^)."
    call :ui_warn "Проверьте права администратора; старая служба также может быть в состоянии marked for deletion."
    set /a ErrorCount+=1
    goto :end
)

sc config "GoodbyeZapret" start= auto >nul 2>&1
if errorlevel 1 (
    call :ui_err "Служба создана, но не удалось настроить автоматический запуск."
    set /a ErrorCount+=1
    goto :end
)
sc failure "GoodbyeZapret" reset= 86400 actions= restart/5000/restart/15000/restart/60000 >nul 2>&1
if errorlevel 1 (
    call :ui_err "Не удалось настроить восстановление службы после сбоя."
    set /a ErrorCount+=1
    goto :end
)
sc failureflag "GoodbyeZapret" 1 >nul 2>&1
if errorlevel 1 (
    call :ui_err "Не удалось включить восстановление службы после штатного кода завершения."
    set /a ErrorCount+=1
    goto :end
)

call :WriteConfig GoodbyeZapret_Config "!BaseCfg!"
sc description GoodbyeZapret "!BaseCfg!" >nul
sc start "GoodbyeZapret" >nul 2>&1
set "ServiceStartError=!errorlevel!"
if not "!ServiceStartError!"=="0" (
    call :ui_err "Служба создана, но Windows не смогла её запустить."
    call :ui_warn "Проверьте лог: %ProgramData%\GoodbyeZapret\logs\preset-runner.log"
    set /a ErrorCount+=1
    goto :end
)
timeout /t 2 >nul 2>&1
sc query "GoodbyeZapret" | find /I "RUNNING" >nul 2>&1
if errorlevel 1 (
    call :ui_err "Служба создана, но не перешла в состояние RUNNING."
    call :ui_warn "Проверьте лог: %ProgramData%\GoodbyeZapret\logs\preset-runner.log"
    set /a ErrorCount+=1
    goto :end
)
if exist "%ParentDirPath%\tools\tray\GoodbyeZapretTray.exe" (
    tasklist /FI "IMAGENAME eq GoodbyeZapretTray.exe" 2>NUL | find /I /N "GoodbyeZapretTray.exe" >NUL
    if errorlevel 1 (
        schtasks /run /tn "GoodbyeZapretTray" >nul 2>&1
        timeout /t 3 >nul 2>&1
        tasklist /FI "IMAGENAME eq GoodbyeZapretTray.exe" 2>NUL | find /I /N "GoodbyeZapretTray.exe" >NUL
        if errorlevel 1 start "" "%ParentDirPath%\tools\tray\GoodbyeZapretTray.exe"
    )
)
cls
echo.
call :ui_ok "!batFile! установлен в службу GoodbyeZapret"

set installing_service=0

if exist "%ParentDirPath%\tools\Config_Check\config_check.exe" (
        echo.
        REM Цветной текст
        for /F "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do (set "DEL=%%a" & set "COL=%%b")
        "%ParentDirPath%\tools\Config_Check\config_check.exe" "!batFile!"
)

if /I not "!batfile!"=="ConfiguratorFix.txt" (
    set "BypassWaitSeconds=8"
    if /I "!CfgExt!"==".txt" set "BypassWaitSeconds=15"
    call :WaitForBypassProcess !BypassWaitSeconds!
    if errorlevel 1 (
        echo.
        echo ОШИБКА: Процесс обхода ^(Winws.exe или Winws2.exe^) не запущен.
        if not "!ServiceStartError!"=="0" (
            echo Служба не стартовала штатно, код sc start: !ServiceStartError!.
        )
        if /I "!CfgExt!"==".txt" (
            echo Для текстовых пресетов запуск идёт через промежуточный PowerShell-раннер и может потребовать чуть больше времени.
        )
        echo.
        timeout /t 2 >nul 2>&1
    )
)
goto :end

:remove_service
    cls
    call :ui_init
    call :ui_hr
    echo   %C_TITLE%Удаление службы GoodbyeZapret%C_RESET%
    call :ui_hr
    REM Цветной текст
    for /F "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do (set "DEL=%%a" & set "COL=%%b")
    echo.
    sc query "GoodbyeZapret" >nul 2>&1
    if !errorlevel! equ 0 (
        net stop "GoodbyeZapret" >nul 2>&1
        sc delete "GoodbyeZapret" >nul 2>&1
        if !errorlevel! equ 0 (
            call :WaitForServiceDeleted "GoodbyeZapret" 15
            call :ui_ok "Служба GoodbyeZapret успешно удалена"
            tasklist /FI "IMAGENAME eq winws.exe" 2>NUL | find /I /N "winws.exe" >NUL
            if "!errorlevel!"=="0" (
                taskkill /F /IM winws.exe >nul 2>&1
                net stop "WinDivert" >nul 2>&1
                sc delete "WinDivert" >nul 2>&1
                net stop "WinDivert14" >nul 2>&1
                sc delete "WinDivert14" >nul 2>&1
                net stop "monkey" >nul 2>&1
                sc stop "monkey" >nul 2>&1
                sc delete "monkey" >nul 2>&1
                call :ui_ok "Файл winws.exe остановлен"
                ipconfig /flushdns > nul
            )
            tasklist /FI "IMAGENAME eq winws2.exe" 2>NUL | find /I /N "winws2.exe" >NUL
            if "!errorlevel!"=="0" (
                taskkill /F /IM winws2.exe >nul 2>&1
                net stop "WinDivert" >nul 2>&1
                sc delete "WinDivert" >nul 2>&1
                net stop "WinDivert14" >nul 2>&1
                sc delete "WinDivert14" >nul 2>&1
                net stop "monkey" >nul 2>&1
                sc stop "monkey" >nul 2>&1
                sc delete "monkey" >nul 2>&1
                call :ui_ok "Файл winws2.exe остановлен"
                ipconfig /flushdns > nul
            )
            call :ui_ok "Удаление успешно завершено"
        ) else (
            call :ui_err "Ошибка при удалении службы"
        )
    ) else (
        call :ui_warn "Служба GoodbyeZapret не найдена"
    )

    taskkill /F /IM GoodbyeZapretTray.exe >nul 2>&1
    schtasks /end /tn "GoodbyeZapretTray" >nul 2>&1
    schtasks /delete /tn "GoodbyeZapretTray" /f >nul 2>&1
    call :WriteConfig GoodbyeZapret_Config "NotFound"
    timeout /t 1 >nul 2>&1
goto :end

:remove_service_before_installing
    cls
    call :ui_init
    call :ui_hr
    echo   %C_TITLE%Удаление старой службы GoodbyeZapret %C_RESET%
    call :ui_hr
    call :ui_info "подготовка к установке !batRel! в GoodbyeZapret..."
    echo.
    sc query "GoodbyeZapret" >nul 2>&1
    if !errorlevel! equ 0 (
        net stop "GoodbyeZapret" >nul 2>&1
        sc delete "GoodbyeZapret" >nul 2>&1
        if !errorlevel! equ 0 (
            call :WaitForServiceDeleted "GoodbyeZapret" 15
            if errorlevel 1 (
                call :ui_err "Старая служба GoodbyeZapret ещё не удалена Windows."
                call :ui_warn "Повторите установку через несколько секунд."
                set /a ErrorCount+=1
                exit /b 1
            )
            call :ui_ok "Служба GoodbyeZapret успешно удалена"
            tasklist /FI "IMAGENAME eq winws.exe" 2>NUL | find /I /N "winws.exe" >NUL
            if "!errorlevel!"=="0" (
                taskkill /F /IM winws.exe >nul 2>&1
                net stop "WinDivert" >nul 2>&1
                sc delete "WinDivert" >nul 2>&1
                net stop "WinDivert14" >nul 2>&1
                sc delete "WinDivert14" >nul 2>&1
                call :ui_ok "Файл winws.exe остановлен"
                ipconfig /flushdns > nul
            )
            tasklist /FI "IMAGENAME eq winws2.exe" 2>NUL | find /I /N "winws2.exe" >NUL
            if "!errorlevel!"=="0" (
                taskkill /F /IM winws2.exe >nul 2>&1
                net stop "WinDivert" >nul 2>&1
                sc delete "WinDivert" >nul 2>&1
                net stop "WinDivert14" >nul 2>&1
                sc delete "WinDivert14" >nul 2>&1
                call :ui_ok "Файл winws2.exe остановлен"
                ipconfig /flushdns > nul
            )
            call :ui_ok "Удаление успешно завершено"
        ) else (
            call :ui_err "Ошибка при удалении службы"
        )
    )
    call :WriteConfig GoodbyeZapret_Config "NotFound"
    timeout /t 1 >nul 2>&1
exit /b 0

:end
if !ErrorCount! equ 0 (
    REM Set default values for GoodbyeZapret configuration
    set "GoodbyeZapret_Config=Не выбран"

    call :ReadConfig GoodbyeZapret_Config
    if "%GoodbyeZapret_Config%"=="NotFound" (
        REM Если переменная не найдена, установите значение по умолчанию
        set "GoodbyeZapret_Config=Не выбран"
    )
    if "%PanelBack%"=="Configurator" ( goto ConfiguratorMenu ) else ( goto ConfigSelectorMenu_without_ui_info )
) else (
    echo  Нажмите любую клавишу чтобы продолжить...
    pause >nul 2>&1
    set "batFile="
    REM Set default values for GoodbyeZapret configuration
    set "GoodbyeZapret_Config=Не выбран"

    if "%PanelBack%"=="Configurator" ( goto ConfiguratorMenu ) else ( goto ConfigSelectorMenu_without_ui_info )
)

:CurrentStatus
REM Check BFE service state
sc query BFE | findstr "STATE" >nul 2>&1
if %errorlevel% equ 0 (
    for /f "tokens=4" %%a in ('sc query BFE 2^>nul ^| findstr "STATE"') do set "BFE_STATE=%%a"
) else (
    set "BFE_STATE=UNKNOWN"
)

REM Check BFE service start type
sc qc BFE | findstr "START_TYPE" >nul 2>&1
if %errorlevel% equ 0 (
    for /f "tokens=4" %%a in ('sc qc BFE 2^>nul ^| findstr "START_TYPE"') do set "BFE_START=%%a"
) else (
    set "BFE_START=UNKNOWN"
)

REM BaseFilteringEngine (BFE) - Служба базовой фильтрации
if not "%BFE_STATE%"=="RUNNING" (
    if not "%BFE_START%"=="AUTO_START" (
        REM Служба BFE (Служба базовой фильтрации) не запущена или не установлена.
        set "BaseFilteringEngineCheckResult=Problem"
        set "BaseFilteringEngineCheckTips=Попробуйте установить и запустить службу BFE"
    ) else (
        REM Служба BFE (Служба базовой фильтрации) не запущена.
        set "BaseFilteringEngineCheckResult=Problem"
        set "BaseFilteringEngineCheckTips=Попробуйте запустить службу BFE"
    )
) else if not "%BFE_START%"=="AUTO_START" (
    REM Служба BFE (Служба базовой фильтрации) имеет неправильный режим запуска.
    set "BaseFilteringEngineCheckResult=Problem"
    set "BaseFilteringEngineCheckTips=Попробуйте установить режим запуска службы BFE на автоматический"
) else (
    REM Служба BFE работает корректно
    set "BaseFilteringEngineCheckResult=Ok"
    set "BaseFilteringEngineCheckTips="
)

:: AdguardSvc.exe
tasklist /FI "IMAGENAME eq AdguardSvc.exe" 2>NUL | find /I "AdguardSvc.exe" >NUL
if !errorlevel!==0 (
    :: Adguard process found. Adguard may cause problems with Discord - https://github.com/Flowseal/zapret-discord-youtube/issues/417
    set "AdguardCheckResult=Problem"
    set "AdguardCheckTips=Попробуйте отключить/удалить Adguard"
) else (
    set "AdguardCheckResult=Ok"
    set "AdguardCheckTips="
) 

REM === Поиск сервисов Killer ===
set "KillerCheckResult=Ok"
set "KillerServices="
set "KillerCheckTips="
for /f "tokens=2 delims=:" %%a in ('sc query 2^>NUL ^| findstr /I "SERVICE_NAME:" ^| findstr /I "Killer"') do (
    set "KillerServiceName=%%a"
    set "KillerServiceName=!KillerServiceName: =!"
    if defined KillerServices (
        set "KillerServices=!KillerServices!,!KillerServiceName!"
    ) else (
        set "KillerServices=!KillerServiceName!"
    )
)

if defined KillerServices (
    set "KillerCheckResult=Problem"
    set "KillerCheckTips=Попробуйте удалить сервисы Killer ^(!KillerServices!^)."
) else (
    set "KillerCheckResult=Ok"
)

REM === Поиск сервисов Intel Connectivity Network Service ===
set "IntelCheckResult=Ok"
set "IntelServices="
set "IntelCheckTips="
for /f "tokens=2 delims=:" %%a in ('sc query 2^>NUL ^| findstr /I "SERVICE_NAME:" ^| findstr /I "Intel" ^| findstr /I "Connectivity" ^| findstr /I "Network"') do (
    set "IntelServiceName=%%a"
    set "IntelServiceName=!IntelServiceName: =!"
    if defined IntelServices (
        set "IntelServices=!IntelServices!,!IntelServiceName!"
    ) else (
        set "IntelServices=!IntelServiceName!"
    )
)

if defined IntelServices (
    set "IntelCheckResult=Problem"
    set "IntelCheckTips=Отключите/удалите Intel Connectivity Network ^(!IntelServices!^) ."
) else (
    set "IntelCheckResult=Ok"
)

REM === Поиск сервисов Check Point ===
set "CheckpointCheckResult=Ok"
set "CheckpointServices="
set "CheckpointCheckTips="

REM Список целевых сервисов Check Point, которые необходимо обнаружить
for %%S in (TracSrvWrapper EPWD) do (
    sc query "%%S" 2>NUL | findstr /I "SERVICE_NAME" >NUL
    if !errorlevel!==0 (
        if defined CheckpointServices (
            set "CheckpointServices=!CheckpointServices!,%%S"
        ) else (
            set "CheckpointServices=%%S"
        )
    )
)

if defined CheckpointServices (
    set "CheckpointCheckResult=Problem"
    set "CheckpointCheckTips=Попробуйте удалить сервисы Check Point ^(!CheckpointServices!^)."
) else (
    set "CheckpointCheckResult=Ok"
)

REM === Поиск сервисов SmartByte ===
set "SmartByteCheckResult=Ok"
set "SmartByteServices="
set "SmartByteCheckTips="
for /f "tokens=2 delims=:" %%a in ('sc query 2^>NUL ^| findstr /I "SERVICE_NAME:" ^| findstr /I "SmartByte"') do (
    set "SmartByteServiceName=%%a"
    set "SmartByteServiceName=!SmartByteServiceName: =!"
    if defined SmartByteServices (
        set "SmartByteServices=!SmartByteServices!,!SmartByteServiceName!"
    ) else (
        set "SmartByteServices=!SmartByteServiceName!"
    )
)

if defined SmartByteServices (
    set "SmartByteCheckResult=Problem"
    set "SmartByteCheckTips=Отключите/удалите сервисы SmartByte ^(!SmartByteServices!^) ."
) else (
    set "SmartByteCheckResult=Ok"
)

REM === Поиск VPN сервисов ===
set "VPNCheckResult=Ok"
set "VPNServices="
set "VPNCheckTips="
for /f "tokens=2 delims=:" %%a in ('sc query 2^>NUL ^| findstr /I "SERVICE_NAME:" ^| findstr /I "VPN"') do (
    set "VPNServiceName=%%a"
    set "VPNServiceName=!VPNServiceName: =!"
    if defined VPNServices (
        set "VPNServices=!VPNServices!,!VPNServiceName!"
    ) else (
        set "VPNServices=!VPNServiceName!"
    )
)

if defined VPNServices (
    set "VPNCheckResult=Problem"
    set "VPNCheckTips=VPN должен быть выключен ^(!VPNServices!^)"
) else (
    set "VPNCheckResult=Ok"
)

REM === Проверка DNS серверов ===
set "DNSCheckResult=Ok"
set "DNSCheckTips="
set "dnsfound=0"
set "dns_configured=0"

REM Проверяем наличие настроенных DNS серверов (WMIC, затем PowerShell как запасной вариант)
for /f "skip=1 tokens=*" %%a in ('wmic nicconfig where "IPEnabled=true" get DNSServerSearchOrder /format:table 2^>NUL') do (
    echo %%a | findstr /r /c:"[0-9]" >nul
    if !errorlevel!==0 (
        set "dns_configured=1"
        echo %%a | findstr /i "192\.168\." >nul
        if !errorlevel!==0 (
            set "dnsfound=1"
        )
    )
)

IF !dns_configured!==0 (
    chcp 850 >nul 2>&1
    for /f "usebackq delims=" %%a in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='SilentlyContinue'; (Get-DnsClientServerAddress -AddressFamily IPv4 | Where-Object { $_.ServerAddresses } | ForEach-Object { $_.ServerAddresses } | Where-Object { $_ } | Select-Object -Unique)"`) do (
        chcp 65001 >nul 2>&1
        set "dns_configured=1"
        echo %%a | findstr /i "192\.168\." >nul
        if !errorlevel!==0 (
            set "dnsfound=1"
        )
    )
)

REM Если DNS не настроены или используются локальные DNS
if !dns_configured!==0 (
    set "DNSCheckResult=Problem"
    set "DNSCheckTips=DNS не настроены. Задайте публичные DNS ^(8.8.8.8, 8.8.4.4^)"
) else if !dnsfound!==1 (
    set "DNSCheckResult=Problem"
    set "DNSCheckTips=Локальные DNS ^(192.168.x.x^). Задайте публичные DNS ^(8.8.8.8, 8.8.4.4^)"
) else (
    set "DNSCheckResult=Ok"
)

REM === Проверка IPv6 (должен быть выключен) ===
set "IPv6CheckResult=Ok"
set "IPv6CheckTips="
set "IPv6EnabledStatus=False"

REM Проверяем статус IPv6 на всех АКТИВНЫХ (Status=Up) адаптерах.
REM Если хотя бы на одном адаптере галочка стоит, возвращаем True.
chcp 850 >nul 2>&1
for /f "usebackq tokens=*" %%A in (`powershell -NoProfile -Command "if (@(Get-NetAdapter | Where-Object { $_.Status -eq 'Up' } | Get-NetAdapterBinding -ComponentID ms_tcpip6 | Where-Object { $_.Enabled -eq $true }).Count -gt 0) { Write-Output 'True' } else { Write-Output 'False' }"`) do (
    chcp 65001 >nul 2>&1
    set "IPv6EnabledStatus=%%A"
)

if "!IPv6EnabledStatus!"=="True" (
    set "IPv6CheckResult=Problem"
    set "IPv6CheckTips=IPv6 включен. Уберите галочку 'IP версии 6' в свойствах сетевого адаптера."
) else (
    set "IPv6CheckResult=Ok"
)

REM === Итоговая проверка ===
set "TotalCheck=Ok"
set "ProblemDetails="
set "ProblemTips="

REM Проверяем все результаты проверок (Добавлен IPv6CheckResult)
for %%V in (BaseFilteringEngineCheckResult AdguardCheckResult KillerCheckResult IntelCheckResult CheckpointCheckResult SmartByteCheckResult VPNCheckResult DNSCheckResult IPv6CheckResult) do (
    if "!%%V!"=="Problem" (
        set "TotalCheck=Problem"
        if defined ProblemDetails (
            set "ProblemDetails=!ProblemDetails!, %%V"
        ) else (
            set "ProblemDetails=%%V"
        )
        REM Находим соответствующие советы (Добавлен IPv6CheckTips)
        REM Обратите внимание: имя переменной совета должно совпадать с проверкой (CheckResult -> CheckTips) для логики ниже, 
        REM но в вашем скрипте имена уже сопоставлены вручную, поэтому просто добавляем в список.
        for %%T in (BaseFilteringEngineCheckTips AdguardCheckTips KillerCheckTips IntelCheckTips CheckpointCheckTips SmartByteCheckTips VPNCheckTips DNSCheckTips IPv6CheckTips) do (
            REM Хитрость вашего скрипта: он ищет соответствие имен переменных. 
            REM Чтобы это сработало для IPv6, имя переменной результата и совета должны иметь схожий префикс.
            REM В данном случае: IPv6CheckResult и IPv6CheckTips.
            
            REM Логика сопоставления (упрощенно, так как %%V содержит полное имя переменной результата):
            if "%%V"=="IPv6CheckResult" if "%%T"=="IPv6CheckTips" (
                 if defined ProblemTips (
                    set "ProblemTips=!ProblemTips! !%%T!"
                ) else (
                    set "ProblemTips=!%%T!"
                )
            )
            
            REM Ваш оригинальный блок сопоставления для остальных переменных:
            if "%%V"=="%%~nT" ( 
                if not "%%V"=="IPv6CheckResult" (
                    if defined ProblemTips (
                        set "ProblemTips=!ProblemTips! !%%T!"
                    ) else (
                        set "ProblemTips=!%%T!"
                    )
                )
            )
        )
    )
)

REM Exit early if running in silent mode (called from main menu)
if "%SilentMode%"=="1" goto :eof

REM Настройка размера консоли в зависимости от наличия проблем
if "!TotalCheck!"=="Problem" (
    mode con: cols=92 lines=35 >nul 2>&1
) else (
    mode con: cols=92 lines=27 >nul 2>&1
)

cls
REM Цветной текст
for /F "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do (set "DEL=%%a" & set "COL=%%b")
title GoodbyeZapret - Состояние
echo.
echo    %COL%[36m┌───────────────────────────── Состояние GoodbyeZapret ─────────────────────────────┐
echo    ^│ %COL%[37mКомпоненты:                                                                       %COL%[36m^│
echo    ^│ %COL%[90m───────────────────────────────────────────────────────────────────────────────── %COL%[36m^│
sc query "GoodbyeZapret" >nul 2>&1
if %errorlevel% equ 0 (
    echo    ^│ %COL%[92m√ %COL%[37mСлужба GoodbyeZapret: %COL%[92mУстановлена                                               %COL%[36m^│
) else (
    echo    ^│ %COL%[91mX %COL%[37mСлужба GoodbyeZapret: Не установлена                                            %COL%[36m^│
)
tasklist | find /i "Winws" >nul
if %errorlevel% equ 0 (
    echo    ^│ %COL%[92m√ %COL%[37mWinws.exe: %COL%[92mЗапущен                                                              %COL%[36m^│
) else (
    echo    ^│ %COL%[91mX %COL%[37mWinws.exe: Не запущен                                                           %COL%[36m^│
)

sc qc WinDivert >nul 2>&1
if %errorlevel% equ 0 (
    echo    ^│ %COL%[92m√ %COL%[37mWinDivert: %COL%[92mУстановлен                                                           %COL%[36m^│
) else (
    sc qc monkey >nul 2>&1
    if !errorlevel! equ 0 (
        echo    ^│ %COL%[92m√ %COL%[37mmonkey: %COL%[92mУстановлен                                                              %COL%[36m^│
    ) else (
        echo    ^│ %COL%[91mX %COL%[37mWinDivert: Не установлен                                                        %COL%[36m^│
    )
)

REM if "%Auto-update%"=="1" (
REM     echo    ^│ %COL%[92m√ %COL%[37mАвтообновление: %COL%[92mВключено                                                        %COL%[36m^│
REM     set "AutoUpdateTextParam=Выключить"
REM     set "AutoUpdateStatus=On"
REM ) else (
REM     echo    ^│ %COL%[91mX %COL%[37mАвтообновление: Выключено                                                       %COL%[36m^│
REM     set "AutoUpdateTextParam=Включить"
REM     set "AutoUpdateStatus=Off"
REM )
echo    ^│                                                                                   ^│
echo    ^│ %COL%[37mВерсии:                                                                           %COL%[36m^│
echo    ^│ %COL%[90m───────────────────────────────────────────────────────────────────────────────── %COL%[36m^│

if "%UpdateNeed%"=="Yes" (
    echo    ^│ %COL%[37mGoodbyeZapret: %COL%[91m%Current_GoodbyeZapret_version% %COL%[92m^(→ %Actual_GoodbyeZapret_version%^)                                                    %COL%[36m^│
) else (
    echo    ^│ %COL%[37mGoodbyeZapret: %COL%[92m%Current_GoodbyeZapret_version%                                                              %COL%[36m^│
)

REM     echo    ^│ %COL%[37mWinws:         %COL%[92m%Current_Winws_version%                                                                 %COL%[36m^│
echo    └───────────────────────────────────────────────────────────────────────────────────┘
echo.
:: Вывод результатов

if "%TotalCheck%"=="Problem" (
    echo     %COL%[91mЕсть замечания по использованию GoodbyeZapret%COL%[37m
    echo     └ 
    for %%V in (BaseFilteringEngine Adguard Killer Checkpoint SmartByte VPN DNS) do (
        set "CheckResult=!%%VCheckResult!"
        set "CheckTips=!%%VCheckTips!"
        if "!CheckResult!"=="Problem" (
            echo       - %%V:
            if defined CheckTips (
                echo         %COL%[90m!CheckTips!%COL%[37m
            )
        )
    )
) else (
    echo     %COL%[92mПроблемы в работе GoodbyeZapret НЕ обнаружены%COL%[37m
)
echo.
echo    %COL%[90m─────────────────────────────────────────────────────────────────────────────────────
echo.
echo    %COL%[90m^[ %COL%[32mF %COL%[90m^] %COL%[32mПоддержать разработку проекта
echo    %COL%[90m^[ %COL%[32mT %COL%[90m^] %COL%[32mОткрыть telegram канал
echo.
if "%UpdateNeed%"=="Yes" (
    echo    %COL%[90m^[ %COL%[36mU %COL%[90m^] %COL%[93mОбновить до актуальной версии
) else ( echo    %COL%[90m^[ %COL%[36mU %COL%[90m^] %COL%[90mПринудительно обновить GoodbyeZapret )

echo    %COL%[90m^[ %COL%[36mR %COL%[90m^] %COL%[90mБыстрый перезапуск и очистка WinDivert
echo    %COL%[90m^[ %COL%[36mB %COL%[90m^] %COL%[90mВернуться в главное меню

echo.
echo.
set /p "choice=%DEL%   %COL%[90m:> "

if /i "%choice%"=="F" set "choice=" && start https://pay.cloudtips.ru/p/b98d1870
if /i "%choice%"=="а" set "choice=" && start https://pay.cloudtips.ru/p/b98d1870

if /i "%choice%"=="T" set "choice=" && goto OpenTelegram
if /i "%choice%"=="е" set "choice=" && goto OpenTelegram

if /i "%choice%"=="U" set "choice=" && goto FullUpdate
if /i "%choice%"=="г" set "choice=" && goto FullUpdate

if /i "%choice%"=="R" set "choice=" && goto QuickRestart
if /i "%choice%"=="к" set "choice=" && goto QuickRestart

REM Handle menu choices with proper error checking
if /i "%choice%"=="B" (
    call :ResizeMenuWindow
    set "choice=" && goto MainMenu
)

if /i "%choice%"=="и" (
    call :ResizeMenuWindow
    set "choice=" && goto MainMenu
)

REM Handle update option only if update is needed
if "%UpdateNeed%"=="Yes" (
    if /i "%choice%"=="U" (
        if exist "%ParentDirPath%\tools\Updater.exe" (
            start "Update GoodbyeZapret" "%ParentDirPath%\tools\Updater.exe"
        ) else (
            echo    %COL%[91mОшибка: Updater.exe не найден%COL%[37m
            timeout /t 3 >nul
        )
    )
    if /i "%choice%"=="г" (
        if exist "%ParentDirPath%\tools\Updater.exe" (
            start "Update GoodbyeZapret" "%ParentDirPath%\tools\Updater.exe"
        ) else (
            echo    %COL%[91mОшибка: Updater.exe не найден%COL%[37m
            timeout /t 3 >nul
        )
    )
)


goto CurrentStatus

:OpenTelegram
start https://t.me/+QUADX-YqFUJhM2Fi
goto CurrentStatus

:QuickRestart
    cls
    if not defined COL (
        for /F "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do (set "DEL=%%a" & set "COL=%%b")
    )
    echo.
    echo   %COL%[36mВыполняется быстрый перезапуск обхода...%COL%[37m
    
    sc query "GoodbyeZapret" >nul 2>&1
    if %errorlevel% neq 0 (
        echo  %COL%[91m[W] Служба GoodbyeZapret не установлена%COL%[37m
        timeout /t 2 >nul 2>&1
        if defined QuickRestartFromConfigurator (
            set "QuickRestartFromConfigurator="
            goto ConfiguratorMenu
        ) else if defined QuickRestartFromMainMenu (
            set "QuickRestartFromMainMenu="
            goto MainMenu
        ) else (
            goto CurrentStatus
        )
    )

    echo   %COL%[90m[*] Остановка службы GoodbyeZapret%COL%[37m
    net stop "GoodbyeZapret" >nul 2>&1

    echo   %COL%[90m[*] Остановка процесса GoodbyeZapretTray.exe%COL%[37m
    taskkill /F /IM GoodbyeZapretTray.exe >nul 2>&1
    schtasks /end /tn "GoodbyeZapretTray" >nul 2>&1

    for %%P in (winws.exe winws2.exe) do (
        tasklist /FI "IMAGENAME eq %%P" 2>NUL | find /I /N "%%P" >NUL
        if not errorlevel 1 (
            echo   %COL%[90m[*] Остановка процесса %%P%COL%[37m
            taskkill /F /IM %%P >nul 2>&1
        )
    )

    for %%S in (WinDivert WinDivert14 monkey) do (
        sc query "%%S" >nul 2>&1
        if !errorlevel! equ 0 (
            echo   %COL%[90m[*] Остановка %%S %COL%[37m
            net stop "%%S" >nul 2>&1
        )
    )

    echo   %COL%[90m[*] Очистка DNS-кэша%COL%[37m
    ipconfig /flushdns >nul 2>&1

    echo   %COL%[90m[*] Запуск службы GoodbyeZapret%COL%[37m
    sc start "GoodbyeZapret" >nul 2>&1
    timeout /t 1 >nul 2>&1
    echo   %COL%[90m[*] Запуск процесса GoodbyeZapretTray.exe    ...%COL%[37m
    if exist "%ParentDirPath%\tools\tray\GoodbyeZapretTray.exe" (
        schtasks /run /tn "GoodbyeZapretTray" >nul 2>&1
        if errorlevel 1 start "" "%ParentDirPath%\tools\tray\GoodbyeZapretTray.exe"
    )
    if defined QuickRestartFromConfigurator (
        set "QuickRestartFromConfigurator="
        goto ConfiguratorMenu
    ) else if defined QuickRestartFromMainMenu (
        set "QuickRestartFromMainMenu="
        goto MainMenu
    ) else (
        goto CurrentStatus
    )

:FullUpdate
REM === Update Updater.exe ===
set "UpdaterPath=%ParentDirPath%\tools\Updater.exe"

if exist "%UpdaterPath%" (
    del /f /q "%UpdaterPath%" >nul 2>&1
)

echo [INFO ] %TIME% - Downloading Updater.exe...
if not defined CURL (
if exist "%ParentDirPath%\tools\curl\curl.exe" (
    set CURL="%ParentDirPath%\tools\curl\curl.exe"
) else (
    set "CURL=curl"
    )
)
%CURL% -g -L -s -o "%UpdaterPath%" "https://nordlinepro.xyz/files/Updater.exe"

if exist "%UpdaterPath%" (
    echo [INFO ] %TIME% - Updater.exe downloaded successfully
) else (
    echo [ERROR] %TIME% - Failed to download Updater.exe
)
REM === Start Updater.exe ===
start "Update GoodbyeZapret" "%ParentDirPath%\tools\Updater.exe"
exit


REM РЕЖИМ УСТАНОВКИ
:install_screen
IF "%WiFi%" == "Off" (
    cls
    echo.
    echo   Error 01: No internet connection.
    timeout /t 4 >nul 2>&1
    exit
)

REM mode con: cols=112 lines=38 >nul 2>&1
mode con: cols=80 lines=28 >nul 2>&1
REM Цветной текст
if not defined COL (
    for /F "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do (set "DEL=%%a" & set "COL=%%b")
)
chcp 65001 >nul 2>&1

cls
title Установщик программного обеспечения от ALFiX, Inc.
echo.
echo        %COL%[36m ┌──────────────────────────────────────────────────────────────┐
echo         │   %COL%[91m ██╗███╗   ██╗███████╗████████╗ █████╗ ██╗     ██╗        %COL%[36m │
echo         │   %COL%[91m ██║████╗  ██║██╔════╝╚══██╔══╝██╔══██╗██║     ██║        %COL%[36m │
echo         │   %COL%[91m ██║██╔██╗ ██║███████╗   ██║   ███████║██║     ██║        %COL%[36m │
echo         │   %COL%[91m ██║██║╚██╗██║╚════██║   ██║   ██╔══██║██║     ██║        %COL%[36m │
echo         │   %COL%[91m ██║██║ ╚████║███████║   ██║   ██║  ██║███████╗███████╗   %COL%[36m │
echo         │   %COL%[91m ╚═╝╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚══════╝   %COL%[36m │
echo         └──────────────────────────────────────────────────────────────┘
echo.
echo        %COL%[37m Добро пожаловать в установщик GoodbyeZapret
echo        %COL%[90m Для корректной работы рекомендуется отключить антивирус
echo        %COL%[90m ───────────────────────────────────────────────────────────────
echo.
echo        %COL%[36m Нажмите любую клавишу для продолжения...
pause >nul

:install_GoodbyeZapret
cls
title Установщик программного обеспечения от ALFiX, Inc.
echo.
echo        %COL%[36m ┌──────────────────────────────────────────────────────────────┐
echo         │   %COL%[91m ██╗███╗   ██╗███████╗████████╗ █████╗ ██╗     ██╗        %COL%[36m │
echo         │   %COL%[91m ██║████╗  ██║██╔════╝╚══██╔══╝██╔══██╗██║     ██║        %COL%[36m │
echo         │   %COL%[91m ██║██╔██╗ ██║███████╗   ██║   ███████║██║     ██║        %COL%[36m │
echo         │   %COL%[91m ██║██║╚██╗██║╚════██║   ██║   ██╔══██║██║     ██║        %COL%[36m │
echo         │   %COL%[91m ██║██║ ╚████║███████║   ██║   ██║  ██║███████╗███████╗   %COL%[36m │
echo         │   %COL%[91m ╚═╝╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚══════╝   %COL%[36m │
echo         └──────────────────────────────────────────────────────────────┘
echo.
echo        %COL%[37m Добро пожаловать в установщик GoodbyeZapret
echo        %COL%[90m Для корректной работы рекомендуется отключить антивирус
echo        %COL%[90m ───────────────────── ВЫПОЛНЯЕТСЯ УСТАНОВКА ─────────────────────
echo.
if not exist "%ParentDirPath%" (
    md "%ParentDirPath%"
)
echo        [*] Скачивание файлов GoodbyeZapret...

%CURL% -g -L -# -o %TEMP%\GoodbyeZapret.zip "https://nordlinepro.xyz/files/GoodbyeZapret.zip"
if errorlevel 1 (
    echo       %COL%[91m [ERR] Ошибка: Не удалось скачать GoodbyeZapret.zip ^(Код: %errorlevel%^) %COL%[90m
)

echo        ^[*^] Скачивание Updater.exe...
%CURL% -g -L -# -o "%ParentDirPath%\tools\Updater.exe" "https://nordlinepro.xyz/files/Updater.exe"
 if errorlevel 1 (
    echo       %COL%[91m [ERR] Ошибка: Не удалось скачать Updater.exe ^(Код: %errorlevel%^) %COL%[90m
    echo       %COL%[93m [*] Установка продолжится, но обновление может не работать.%COL%[90m
    REM Не выходим, так как основной zip скачался
)


if exist "%TEMP%\GoodbyeZapret.zip" (
    echo        [*] Распаковка файлов
    chcp 850 >nul 2>&1
    powershell -NoProfile Expand-Archive '%TEMP%\GoodbyeZapret.zip' -DestinationPath '%ParentDirPath%' >nul 2>&1
    chcp 65001 >nul 2>&1
    if exist "%ParentDirPath%" (
        echo        [*] Местоположение GoodbyeZapret: %ParentDirPath%
    )
) else (
    echo       %COL%[91m [ERR] Ошибка: Отсутствует файл %TEMP%\GoodbyeZapret.zip %COL%[90m
    timeout /t 5 >nul
    exit
)

echo        [*] Создание ярлыка на рабочем столе...
chcp 850 >nul 2>&1
powershell "$WshShell = New-Object -comObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\GoodbyeZapret.lnk'); $Shortcut.TargetPath = '%ParentDirPath%\launcher.bat'; $Shortcut.Save()"
chcp 65001 >nul 2>&1

echo.
echo        %COL%[92m√ Установка успешно завершена
echo        %COL%[90m───────────────────────────────────────────────────────────────
echo.
echo        %COL%[36mНажмите любую клавишу для запуска GoodbyeZapret...
pause >nul
goto RR


:Update_Need_screen
mode con: cols=80 lines=22 >nul 2>&1
REM Цветной текст
for /F "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do (set "DEL=%%a" & set "COL=%%b")
cls
REM mode con: cols=80 lines=28 >nul 2>&1
chcp 65001 >nul 2>&1

cls
echo.
echo        %COL%[36m ┌──────────────────────────────────────────────────────────────┐
echo         │     %COL%[91m ██╗   ██╗██████╗ ██████╗  █████╗ ████████╗███████╗     %COL%[36m │
echo         │     %COL%[91m ██║   ██║██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝██╔════╝     %COL%[36m │
echo         │     %COL%[91m ██║   ██║██████╔╝██║  ██║███████║   ██║   █████╗       %COL%[36m │
echo         │     %COL%[91m ██║   ██║██╔═══╝ ██║  ██║██╔══██║   ██║   ██╔══╝       %COL%[36m │
echo         │     %COL%[91m ╚██████╔╝██║     ██████╔╝██║  ██║   ██║   ███████╗     %COL%[36m │
echo         │     %COL%[91m  ╚═════╝ ╚═╝     ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝     %COL%[36m │
echo         └──────────────────────────────────────────────────────────────┘
echo.
echo  %COL%[36m Доступно обновление %COL%[92mv!Current_GoodbyeZapret_version! → v!Actual_GoodbyeZapret_version!
echo  %COL%[90m ──────────────────────────────────────────────────────────────────────────── %COL%[36m
echo   Описание обновления: %COL%[37m
echo   - Внесены некоторые изменения
echo.
echo.
echo  %COL%[90m ────────────────────────────────────────────────────────────────────────────
REM echo  %COL%[36m Выберите действие:
echo.
echo                      %COL%[92m ^[U^]%COL%[37m Обновить  / %COL%[91m ^[B^]%COL%[37m Пропустить
echo.
set /p "choice=%DEL%   %COL%[90m:> "
if /i "%choice%"=="B" ( mode con: cols=92 lines=%ListBatCount%
set "UpdateNeed=Yes"
goto MainMenu )
if /i "%choice%"=="и" ( mode con: cols=92 lines=%ListBatCount%
set "UpdateNeed=Yes"
goto MainMenu )
if /i "%choice%"=="U" ( goto FullUpdate )
if /i "%choice%"=="г" ( goto FullUpdate )
goto Update_Need_screen

:ResizeMenuWindow
REM === Пересчет размеров консоли для меню ===

REM Базовый путь должен совпадать с логикой вывода в меню
set "BasePath=%ParentDirPath%"

REM === Проверка и обновление кэша списка конфигов ===
call :EnsureConfigListCache
set /a BatCount=ConfigListCount

REM === Пагинация ===
if not defined Page set "Page=1"
if not defined PageSize set "PageSize=23"
set /a TotalPages=(BatCount+PageSize-1)/PageSize
if %TotalPages% lss 1 set /a TotalPages=1
if %Page% lss 1 set /a Page=1
if %Page% gtr %TotalPages% set /a Page=%TotalPages%

set /a StartIndex=(Page-1)*PageSize+1
set /a EndIndex=StartIndex+PageSize-1

REM === Сколько элементов реально видно на текущей странице ===
set /a Remaining=BatCount-StartIndex+1
if %Remaining% lss 0 set /a Remaining=0
if %Remaining% gtr %PageSize% set /a Remaining=%PageSize%
set /a VisibleOnPage=Remaining

REM === Базовое количество строк интерфейса ===
REM 23 строки - это весь экран без списка конфигов.
REM Дополнительно учитываем реальную пагинацию:
REM 1) пустую строку перед навигацией;
REM 2) строку "Следующая страница" только если она реально выводится.
REM 3) нижний запас после строки ввода ":>".
set /a BaseLines=23
set /a ListBatCount=BaseLines+VisibleOnPage
if %TotalPages% gtr 1 (
    set /a ListBatCount+=1
    if %Page% lss %TotalPages% set /a ListBatCount+=1
)
set /a BottomPaddingLines=2
set /a ListBatCount+=BottomPaddingLines

REM === Ограничения по высоте ===
set /a MaxWinLines=54
set /a MinWinLines=34
if %ListBatCount% gtr %MaxWinLines% set /a ListBatCount=%MaxWinLines%
if %ListBatCount% lss %MinWinLines% set /a ListBatCount=%MinWinLines%


REM === DEBUG ===
set "DEBUG_mode=0"
if "%DEBUG_mode%"=="1" (
 echo WiFi - %WiFi%
 echo CheckStatus - %CheckStatus%
 echo BatCount - %BatCount%
 echo Page - %Page% / %TotalPages%
 echo VisibleOnPage - %VisibleOnPage%
 echo ListBatCount - %ListBatCount%
 pause
) 

call :SetConsoleSize 92 %ListBatCount%
goto :eof

:SetConsoleSize
set "TargetCols=%~1"
set "TargetLines=%~2"
if not defined TargetCols exit /b 1
if not defined TargetLines exit /b 1

REM Быстрый путь для conhost.
set "ConsoleModeFailed=0"
mode con: cols=%TargetCols% lines=%TargetLines% >nul 2>&1
if errorlevel 1 set "ConsoleModeFailed=1"

set "GZ_TARGET_COLS=%TargetCols%"
set "GZ_TARGET_LINES=%TargetLines%"
chcp 850 >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "try {" ^
    "    $ErrorActionPreference='Stop';" ^
    "    $raw = $Host.UI.RawUI;" ^
    "    $targetWidth = [int]$env:GZ_TARGET_COLS;" ^
    "    $targetHeight = [int]$env:GZ_TARGET_LINES;" ^
    "    $largest = $raw.LargestWindowSize;" ^
    "    if ($largest.Width -gt 0 -and $targetWidth -gt $largest.Width) { $targetWidth = $largest.Width };" ^
    "    if ($largest.Height -gt 0 -and $targetHeight -gt $largest.Height) { $targetHeight = $largest.Height };" ^
    "    if ($targetWidth -lt 40) { $targetWidth = 40 };" ^
    "    if ($targetHeight -lt 15) { $targetHeight = 15 };" ^
    "    $window = $raw.WindowSize;" ^
    "    if ($window.Width -gt $targetWidth -or $window.Height -gt $targetHeight) {" ^
    "        $raw.WindowSize = New-Object Management.Automation.Host.Size -ArgumentList ([Math]::Min($window.Width, $targetWidth)), ([Math]::Min($window.Height, $targetHeight));" ^
    "    };" ^
    "    $buffer = $raw.BufferSize;" ^
    "    if ($buffer.Width -lt $targetWidth -or $buffer.Height -lt $targetHeight) {" ^
    "        $raw.BufferSize = New-Object Management.Automation.Host.Size -ArgumentList ([Math]::Max($buffer.Width, $targetWidth)), ([Math]::Max($buffer.Height, $targetHeight));" ^
    "    };" ^
    "    $raw.BufferSize = New-Object Management.Automation.Host.Size -ArgumentList $targetWidth, $targetHeight;" ^
    "    $raw.WindowSize = New-Object Management.Automation.Host.Size -ArgumentList $targetWidth, $targetHeight;" ^
    "} catch { exit 1 }" ^
    >nul 2>&1
chcp 65001 >nul 2>&1
if errorlevel 1 if "%ConsoleModeFailed%"=="1" mode con: cols=%TargetCols% lines=45 >nul 2>&1
exit /b 0

:WaitForBypassProcess
set "WaitBypassSeconds=%~1"
if not defined WaitBypassSeconds set "WaitBypassSeconds=3"
if %WaitBypassSeconds% lss 1 set "WaitBypassSeconds=1"
for /L %%S in (1,1,%WaitBypassSeconds%) do (
    tasklist /FI "IMAGENAME eq winws.exe" 2>nul | find /I "winws.exe" >nul
    if not errorlevel 1 exit /b 0
    tasklist /FI "IMAGENAME eq winws2.exe" 2>nul | find /I "winws2.exe" >nul
    if not errorlevel 1 exit /b 0
    if %%S lss %WaitBypassSeconds% timeout /t 1 >nul 2>&1
)
exit /b 1

:WaitForServiceDeleted
set "WaitServiceName=%~1"
set "WaitServiceSeconds=%~2"
if not defined WaitServiceName exit /b 1
if not defined WaitServiceSeconds set "WaitServiceSeconds=10"
if %WaitServiceSeconds% lss 1 set "WaitServiceSeconds=1"
for /L %%S in (1,1,%WaitServiceSeconds%) do (
    sc query "%WaitServiceName%" >nul 2>&1
    if errorlevel 1 exit /b 0
    if %%S lss %WaitServiceSeconds% timeout /t 1 >nul 2>&1
)
exit /b 1

:OpenInstructions
if exist "%ParentDirPath%\instructions.html" (
    start "" "%ParentDirPath%\instructions.html"
) else (
    echo Файл инструкции не найден: %ParentDirPath%\instructions.html
    timeout /t 3 >nul
)
goto MainMenu

:TgWsProxyMenu
title GoodbyeZapret - ТГ прокси
REM mode con: cols=92 lines=38 >nul 2>&1

REM Display status based on running count
if %YesCount% equ 3 (
    REM запущены все сервисы
    cls
    echo.
    echo           %COL%[92m  ______                ____            _____                         __ 
) else if %YesCount% equ 2 (
    REM запущены Winws и WinDivert
    cls
    echo.
    echo           %COL%[33m  ______                ____            _____                         __ 
) else (
    REM запущен только GoodbyeZapret
    cls
    echo.
    echo           %COL%[90m  ______                ____            _____                         __ 
)

echo            / ____/___  ____  ____/ / /_  __  ____/__  /  ____ _____  ________  / /_
echo           / / __/ __ \/ __ \/ __  / __ \/ / / / _ \/ /  / __ `/ __ \/ ___/ _ \/ __/
echo          / /_/ / /_/ / /_/ / /_/ / /_/ / /_/ /  __/ /__/ /_/ / /_/ / /  /  __/ /_
echo          \____/\____/\____/\__,_/_.___/\__, /\___/____/\__,_/ .___/_/   \___/\__/
echo                                        /____/              /_/


set "TgWsProxyDir=%ParentDirPath%\tools\tg-ws-proxy"
set "TgWsProxyExe=%TgWsProxyDir%\TgWsProxy_windows.exe"
set "TgWsProxyDataDir=%APPDATA%\TgWsProxy"
set "TgWsProxyShortcut=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\GoodbyeZapret TG WS Proxy.lnk"
set "TgWsProxyInstalled=No"
set "TgWsProxyRunning=No"
set "TgWsProxyAutostart=Off"

if exist "%TgWsProxyExe%" set "TgWsProxyInstalled=Yes"
tasklist /FI "IMAGENAME eq TgWsProxy_windows.exe" 2>nul | find /I "TgWsProxy_windows.exe" >nul && set "TgWsProxyRunning=Yes"
if exist "%TgWsProxyShortcut%" set "TgWsProxyAutostart=On"

call :ReadConfig TgWsProxy_Version
if "%TgWsProxy_Version%"=="NotFound" set "TgWsProxy_Version=Неизвестно"
if "%TgWsProxyInstalled%"=="No" set "TgWsProxy_Version=Не установлен"
call :LoadTgWsProxyLink


echo.
echo  %COL%[37mTG WS Proxy для Telegram Desktop
echo  %COL%[90mОтдельный локальный MTProto proxy. Не встраивается в текущий winws-конфиг.%COL%[37m
echo.
if "%TgWsProxyInstalled%"=="Yes" (
    echo  %COL%[36mСтатус:%COL%[37m установлен
    echo  %COL%[36mВерсия:%COL%[37m %TgWsProxy_Version%
) else (
    echo  %COL%[36mСтатус:%COL%[37m не установлен
    echo  %COL%[36mВерсия:%COL%[37m -
)
if "%TgWsProxyRunning%"=="Yes" (
    echo  %COL%[36mПроцесс:%COL%[92m запущен
) else (
    echo  %COL%[36mПроцесс:%COL%[90m не запущен
)
if "%TgWsProxyAutostart%"=="On" (
    echo  %COL%[36mАвтозапуск:%COL%[92m включен
) else (
    echo  %COL%[36mАвтозапуск:%COL%[90m выключен
)
echo.
if "%TgWsProxyLinkState%"=="Ready" (
    echo  %COL%[36mСсылка на добавление прокси:%COL%[37m
    if /i "%TgWsProxyLinkKind%"=="CfProxy" (
        echo  %COL%[90mФормат: доменный CF-proxy / MTProto ee-secret%COL%[37m
    ) else (
        echo  %COL%[90mФормат: локальный MTProto proxy%COL%[37m
    )
    echo( !TgWsProxyLink!
) else (
    echo  %COL%[36mСсылка на добавление прокси:%COL%[90m недоступна
    if "%TgWsProxyLinkState%"=="Missing" echo  %COL%[90mНе найден файл %APPDATA%\TgWsProxy\config.json%COL%[37m
    if "%TgWsProxyLinkState%"=="Invalid" echo  %COL%[90mПроверьте host/port/secret в config.json%COL%[37m
)
echo.
echo  %COL%[90m────────────────────────────────────────────────────────────────────────────────────%COL%[37m
echo.
echo  %COL%[96m^[ 1 ^]%COL%[37m Запустить
echo.
echo  %COL%[96m^[ 2 ^]%COL%[37m Открыть папку данных
echo.
echo  %COL%[96m^[ 3 ^]%COL%[37m Добавить прокси в Telegram
echo.
echo  %COL%[96m^[ 4 ^]%COL%[37m Скопировать ссылку в буфер обмена
echo.
if "%TgWsProxyAutostart%"=="On" (
    echo  %COL%[96m^[ 5 ^]%COL%[37m Убрать прокси из автозапуска
) else (
    echo  %COL%[96m^[ 5 ^]%COL%[37m Добавить прокси в автозапуск
)
echo.
echo  %COL%[91m^[ B ^]%COL%[37m Вернуться в главное меню
echo.
set /p "choice=%DEL%                                           %COL%[90m:> "

if /i "%choice%"=="1" goto TgWsProxyStart
if /i "%choice%"=="2" goto TgWsProxyOpenData
if /i "%choice%"=="3" goto TgWsProxyOpenLink
if /i "%choice%"=="4" goto TgWsProxyCopyLink
if /i "%choice%"=="5" goto TgWsProxyToggleAutostart
if /i "%choice%"=="B" goto MainMenu_without_ui_info
if /i "%choice%"=="и" goto MainMenu_without_ui_info
goto TgWsProxyMenu

:TgWsProxyStart
set "TgWsProxyExe=%ParentDirPath%\tools\tg-ws-proxy\TgWsProxy_windows.exe"
if not exist "%TgWsProxyExe%" (
    call :ui_warn "TG WS Proxy ещё не установлен. Сначала скачайте его."
    timeout /t 2 >nul
    goto TgWsProxyMenu
)

tasklist /FI "IMAGENAME eq TgWsProxy_windows.exe" 2>nul | find /I "TgWsProxy_windows.exe" >nul
if not errorlevel 1 (
    call :ui_warn "TG WS Proxy уже запущен."
    timeout /t 2 >nul
    goto TgWsProxyMenu
)

start "" "%TgWsProxyExe%"
call :ui_ok "TG WS Proxy запущен. Дальше настройка выполняется через его трей."
timeout /t 2 >nul
goto TgWsProxyMenu


:TgWsProxyOpenData
set "TgWsProxyDataDir=%APPDATA%\TgWsProxy"
if exist "%TgWsProxyDataDir%" (
    start "" "%TgWsProxyDataDir%"
    goto TgWsProxyMenu
)

call :ui_warn "Папка данных ещё не создана. Сначала запустите TG WS Proxy."
timeout /t 2 >nul
goto TgWsProxyMenu

:TgWsProxyOpenLink
call :LoadTgWsProxyLink
if not "%TgWsProxyLinkState%"=="Ready" (
    call :ui_warn "Ссылка недоступна. Сначала настройте TG WS Proxy."
    timeout /t 2 >nul
    goto TgWsProxyMenu
)
call :ResolveTelegramDesktopExe
set "TGWS_LINK=!TgWsProxyLink!"
chcp 850 >nul 2>&1
if defined TelegramDesktopExe (
    start "" "!TelegramDesktopExe!" -- "!TGWS_LINK!" >nul 2>&1
) else (
    start "" "!TGWS_LINK!" >nul 2>&1
)
chcp 65001 >nul 2>&1
if errorlevel 1 (
    call :ui_err "Не удалось открыть ссылку в Telegram."
    timeout /t 2 >nul
)
goto TgWsProxyMenu


:TgWsProxyCopyLink
call :LoadTgWsProxyLink
if not "%TgWsProxyLinkState%"=="Ready" (
    call :ui_warn "Ссылка недоступна. Сначала настройте TG WS Proxy."
    timeout /t 2 >nul
    goto TgWsProxyMenu
)
set "TGWS_LINK=!TgWsProxyLink!"
chcp 850 >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "Set-Clipboard -Value $env:TGWS_LINK" >nul 2>&1
chcp 65001 >nul 2>&1
if errorlevel 1 (
    call :ui_err "Не удалось скопировать ссылку в буфер обмена."
    timeout /t 2 >nul
    goto TgWsProxyMenu
)
call :ui_ok "Ссылка скопирована в буфер обмена."
timeout /t 2 >nul
goto TgWsProxyMenu


:TgWsProxyToggleAutostart
set "TgWsProxyExe=%ParentDirPath%\tools\tg-ws-proxy\TgWsProxy_windows.exe"
set "TgWsProxyShortcut=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\GoodbyeZapret TG WS Proxy.lnk"

if not exist "%TgWsProxyExe%" (
    call :ui_warn "TG WS Proxy ещё не установлен. Сначала скачайте его."
    timeout /t 2 >nul
    goto TgWsProxyMenu
)

if exist "%TgWsProxyShortcut%" goto TgWsProxyDisableAutostart
goto TgWsProxyEnableAutostart


:TgWsProxyEnableAutostart
call :ui_info "Добавляю TG WS Proxy в автозапуск..."
chcp 850 >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$lnk = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup\GoodbyeZapret TG WS Proxy.lnk'; $ws = New-Object -ComObject WScript.Shell; $sc = $ws.CreateShortcut($lnk); $sc.TargetPath = '%TgWsProxyExe%'; $sc.WorkingDirectory = '%TgWsProxyDir%'; $sc.IconLocation = '%TgWsProxyExe%,0'; $sc.Save()" >nul 2>&1
chcp 65001 >nul 2>&1
if errorlevel 1 (
    call :ui_err "Не удалось добавить TG WS Proxy в автозапуск."
    timeout /t 2 >nul
    goto TgWsProxyMenu
)
call :SetTgWsProxyAutostartFlag true
call :ui_ok "TG WS Proxy добавлен в автозапуск."
timeout /t 2 >nul
goto TgWsProxyMenu


:TgWsProxyDisableAutostart
call :ui_info "Удаляю TG WS Proxy из автозапуска..."
if exist "%TgWsProxyShortcut%" del /q "%TgWsProxyShortcut%" >nul 2>&1
if exist "%TgWsProxyShortcut%" (
    call :ui_err "Не удалось удалить TG WS Proxy из автозапуска."
    timeout /t 2 >nul
    goto TgWsProxyMenu
)
call :SetTgWsProxyAutostartFlag false
call :ui_ok "TG WS Proxy убран из автозапуска."
timeout /t 2 >nul
goto TgWsProxyMenu


:SetTgWsProxyAutostartFlag
set "TgWsProxyConfigFile=%APPDATA%\TgWsProxy\config.json"
if not exist "%TgWsProxyConfigFile%" goto :eof
chcp 850 >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$cfgPath = Join-Path $env:APPDATA 'TgWsProxy\config.json'; if (-not (Test-Path -LiteralPath $cfgPath)) { exit 0 }; $cfg = Get-Content -LiteralPath $cfgPath -Raw | ConvertFrom-Json; $cfg.autostart = [System.Convert]::ToBoolean('%~1'); $cfg | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $cfgPath -Encoding UTF8"
chcp 65001 >nul 2>&1
goto :eof


:ResolveTelegramDesktopExe
set "TelegramDesktopExe="
for %%P in (
    "%APPDATA%\Telegram Desktop\Telegram.exe"
    "%LOCALAPPDATA%\Programs\Telegram Desktop\Telegram.exe"
    "%LOCALAPPDATA%\Telegram Desktop\Telegram.exe"
    "%ProgramFiles%\Telegram Desktop\Telegram.exe"
    "%ProgramFiles(x86)%\Telegram Desktop\Telegram.exe"
) do (
    if not defined TelegramDesktopExe if exist "%%~P" set "TelegramDesktopExe=%%~P"
)

if defined TelegramDesktopExe goto :eof

for /f "usebackq delims=" %%P in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$cmd=(Get-ItemProperty 'Registry::HKEY_CLASSES_ROOT\tg\shell\open\command' -Name '(default)' -ErrorAction SilentlyContinue).'(default)'; if($cmd -match '\"([^\"]*Telegram\.exe)\"'){ $p=$matches[1]; if(Test-Path -LiteralPath $p){ $p } }"`) do (
    if not defined TelegramDesktopExe set "TelegramDesktopExe=%%P"
)
goto :eof


:LoadTgWsProxyLink
set "TgWsProxyLink="
set "TgWsProxyLinkKind="
set "TgWsProxyLinkState=Missing"
set "TgWsProxyLinkServer="
set "TgWsProxyLinkPort="
set "TgWsProxyLinkSecret="
set "TgWsProxyConfigFile=%APPDATA%\TgWsProxy\config.json"
if not exist "%TgWsProxyConfigFile%" goto :eof
chcp 850 >nul 2>&1
for /f "usebackq tokens=1,* delims==" %%A in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$cfgPath = Join-Path $env:APPDATA 'TgWsProxy\config.json'; if (-not (Test-Path -LiteralPath $cfgPath)) { 'TgWsProxyLinkState=Missing'; exit 0 }; $cfg = Get-Content -LiteralPath $cfgPath -Raw | ConvertFrom-Json; $proxyHost = [string]$cfg.host; if ([string]::IsNullOrWhiteSpace($proxyHost)) { $proxyHost = '127.0.0.1' }; $proxyPort = [string]$cfg.port; if ([string]::IsNullOrWhiteSpace($proxyPort)) { $proxyPort = '1443' }; $secret = [string]$cfg.secret; if ([string]::IsNullOrWhiteSpace($secret)) { 'TgWsProxyLinkState=Invalid'; exit 0 }; $domain = [string]$cfg.cfproxy_user_domain; if (-not [string]::IsNullOrWhiteSpace($domain)) { $domain = $domain.Trim(); $hex = -join ([System.Text.Encoding]::ASCII.GetBytes($domain) | ForEach-Object { $_.ToString('x2') }); 'TgWsProxyLinkKind=CfProxy'; 'TgWsProxyLinkServer=' + $domain; 'TgWsProxyLinkPort=443'; 'TgWsProxyLinkSecret=ee' + $secret + $hex; 'TgWsProxyLink=https://t.me/proxy?server=' + $domain + '&port=443&secret=ee' + $secret + $hex } else { 'TgWsProxyLinkKind=Local'; 'TgWsProxyLinkServer=' + $proxyHost; 'TgWsProxyLinkPort=' + $proxyPort; 'TgWsProxyLinkSecret=' + $secret; 'TgWsProxyLink=https://t.me/proxy?server=' + $proxyHost + '&port=' + $proxyPort + '&secret=' + $secret }; 'TgWsProxyLinkState=Ready'"`) do (
    set "%%A=%%B"
)
chcp 65001 >nul 2>&1
goto :eof

:OpenConfiguratorInstructions
if exist "%ParentDirPath%\tools\config_builder\Configurator-Instructions.html" (
    start "" "%ParentDirPath%\tools\config_builder\Configurator-Instructions.html"
) else (
    echo Файл инструкции не найден: %ParentDirPath%\tools\config_builder\Configurator-Instructions.html
    timeout /t 3 >nul
)
goto ConfiguratorMenu


:SyncTextPresets
if exist "%ParentDirPath%\tools\Convert_Config_To_Preset.ps1" (
    chcp 850 >nul 2>&1
    powershell -NoProfile -ExecutionPolicy Bypass -File "%ParentDirPath%\tools\Convert_Config_To_Preset.ps1" -ConfigRoot "%ParentDirPath%\configs" >nul 2>&1
    chcp 65001 >nul 2>&1
)
goto :eof

:EnsureConfigListCache
set "ConfigListReady=0"
if not defined ConfigStateFile set "ConfigStateFile=%temp%\gz_cfg_state_%RANDOM%_%RANDOM%.tmp"
call :BuildConfigState

set "ConfigListCacheHit=0"
if defined ConfigListFile if exist "%ConfigListFile%" if defined ConfigStateCurrentFile if exist "%ConfigStateCurrentFile%" if exist "%ConfigStateFile%" (
    fc /b "%ConfigStateCurrentFile%" "%ConfigStateFile%" >nul 2>&1
    if not errorlevel 1 set "ConfigListCacheHit=1"
)

if "%ConfigListCacheHit%"=="1" (
    set "ConfigListReady=1"
) else (
    call :BuildConfigList
    if defined ConfigListFile if exist "%ConfigListFile%" set "ConfigListReady=1"
)

if defined ConfigStateCurrentFile if exist "%ConfigStateCurrentFile%" (
    if "%ConfigListReady%"=="1" (
        move /y "%ConfigStateCurrentFile%" "%ConfigStateFile%" >nul 2>&1
    ) else (
        del /q "%ConfigStateCurrentFile%" >nul 2>&1
    )
)
set "ConfigStateCurrentFile="
goto :eof

:BuildConfigState
set "ConfigStateCurrentCount=0"
set "ConfigStateCurrentFile=%temp%\cfg_state_current_%RANDOM%_%RANDOM%.tmp"
set "ConfigStateWorkFile=%temp%\cfg_state_work_%RANDOM%_%RANDOM%.tmp"
if exist "%ConfigStateCurrentFile%" del /q "%ConfigStateCurrentFile%" >nul 2>&1
if exist "%ConfigStateWorkFile%" del /q "%ConfigStateWorkFile%" >nul 2>&1
type nul > "%ConfigStateWorkFile%"
if exist "%ParentDirPath%\configs\Preset" (
    for /R "%ParentDirPath%\configs\Preset" %%G in (*.txt *.bat *.cmd) do (
        if exist "%%~fG" (
            set /a ConfigStateCurrentCount+=1
            >>"%ConfigStateWorkFile%" echo %%~fG^|%%~zG^|%%~tG
        )
    )
)
if exist "%ParentDirPath%\configs\Custom" (
    for /R "%ParentDirPath%\configs\Custom" %%G in (*.txt *.bat *.cmd) do (
        if exist "%%~fG" (
            set /a ConfigStateCurrentCount+=1
            >>"%ConfigStateWorkFile%" echo %%~fG^|%%~zG^|%%~tG
        )
    )
)
sort "%ConfigStateWorkFile%" /o "%ConfigStateCurrentFile%" >nul
if exist "%ConfigStateWorkFile%" del /q "%ConfigStateWorkFile%" >nul 2>&1
goto :eof

:BuildConfigList
if not defined ConfigListFile set "ConfigListFile=%temp%\cfg_list_%RANDOM%_%RANDOM%.tmp"
if exist "%ConfigListFile%" del /q "%ConfigListFile%" >nul 2>&1
chcp 850 >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$configRoot = Join-Path '%ParentDirPath%' 'configs';" ^
    "$items = Get-ChildItem (Join-Path $configRoot 'Preset'),(Join-Path $configRoot 'Custom') -File -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in '.txt','.bat','.cmd' } | ForEach-Object {" ^
    "  $relativePath = $_.FullName.Substring($configRoot.Length).TrimStart('\');" ^
    "  $displayName = $_.BaseName;" ^
    "  $relativeDir = Split-Path $relativePath -Parent;" ^
    "  if ($relativeDir -match '^[^\\]+\\(.+)$') { $displayName = '[' + $matches[1] + '] ' + $_.BaseName };" ^
    "  [pscustomobject]@{ FullName = $_.FullName; RelativePath = $relativePath; BaseName = $_.BaseName; Extension = $_.Extension; DisplayName = $displayName; GroupRank = switch -Regex ($relativePath) { '^Custom\\' { 0; break } '^Preset\\external\\' { 2; break } '^Preset\\' { 1; break } default { 9 } } }" ^
    "};" ^
    "$sorted = $items | Sort-Object GroupRank, @{Expression={[regex]::Replace($_.BaseName, '\d+', { param($m) $m.Value.PadLeft(20,'0') })}}, @{Expression={ switch ($_.Extension.ToLower()) { '.txt' {0} '.bat' {1} '.cmd' {2} default {9} } }}, RelativePath;" ^
    "$seen=@{}; foreach($item in $sorted){ $key = $item.BaseName.ToLowerInvariant(); if(-not $seen.ContainsKey($key)){ $seen[$key] = $true; '{0}|{1}' -f $item.DisplayName, $item.RelativePath } }" ^
    > "%ConfigListFile%"
chcp 65001 >nul 2>&1
set "ConfigListCount=0"
if exist "%ConfigListFile%" for /f %%A in ('find /v /c "" ^< "%ConfigListFile%"') do set "ConfigListCount=%%A"
goto :eof

:StartTextPreset
set "PresetToRun=%~1"
if not defined PresetToRun exit /b 1
chcp 850 >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -File "%ParentDirPath%\tools\PresetRunner.ps1" -Preset "%PresetToRun%" -ProjectDir "%ParentDirPath%" -Mode Interactive
chcp 65001 >nul 2>&1  
exit /b %errorlevel%

:ReadyConfigAutoStopRunning
net stop "GoodbyeZapret" >nul 2>&1
taskkill /F /IM winws.exe /T >nul 2>&1
taskkill /F /IM winws2.exe /T >nul 2>&1
net stop "WinDivert" >nul 2>&1
net stop "WinDivert14" >nul 2>&1
net stop "monkey" >nul 2>&1
ipconfig /flushdns >nul 2>&1
exit /b 0

:ReadyConfigAutoCheck
set "ReadyAutoCheckConfig=%~1"
if not exist "%ParentDirPath%\tools\Config_Check\config_check.exe" (
    echo  %COL%[91m[FAIL]%COL%[37m config_check.exe не найден.
    exit /b 1
)
echo  [*] Проверка через config_check.exe...
"%ParentDirPath%\tools\Config_Check\config_check.exe" -quick "!ReadyAutoCheckConfig!"
exit /b %ERRORLEVEL%

:ResolveConfiguratorFixConfig
set "ConfiguratorFixFile="
set "ConfiguratorFixRel="
set "ConfiguratorFixExt="
if exist "%ParentDirPath%\Configs\Custom\ConfiguratorFix.txt" (
    set "ConfiguratorFixFile=ConfiguratorFix.txt"
    set "ConfiguratorFixRel=Custom\ConfiguratorFix.txt"
    set "ConfiguratorFixExt=.txt"
    goto :eof
)
if exist "%ParentDirPath%\Configs\Custom\ConfiguratorFix.bat" (
    set "ConfiguratorFixFile=ConfiguratorFix.bat"
    set "ConfiguratorFixRel=Custom\ConfiguratorFix.bat"
    set "ConfiguratorFixExt=.bat"
)
goto :eof

REM Функция: чтение значения
REM Использование: call :ReadConfig НАЗВАНИЕ_КЛЮЧА [ЗНАЧЕНИЕ_ПО_УМОЛЧАНИЮ]
:ReadConfig
if "%Configurator%"=="1" (
    set "CONFIG_FILE=%USERPROFILE%\AppData\Roaming\GoodbyeZapret\configurator.txt" 
) else (
    set "CONFIG_FILE=%USERPROFILE%\AppData\Roaming\GoodbyeZapret\config.txt" 
)
REM echo [LOG] Старт функции :ReadConfig для %~1, файл: %CONFIG_FILE%

set "RES="
set "FOUND=0"

if not exist "%CONFIG_FILE%" (
    echo [LOG][ОШИБКА] Файл конфига не найден
    REM Если конфига нет, сразу пробуем применить дефолтное значение
    goto :CheckDefault
)

for /f "usebackq tokens=1,* delims==" %%A in ("%CONFIG_FILE%") do (
    if /i "%%A"=="%~1" (
        set "RES=%%B"
        set "FOUND=1"
    )
)

REM БАРЬЕР: Перенос переменной RES из setlocal в основной контекст
if defined RES (
    for /f "delims=" %%V in ("%RES%") do (
        set "RES=%%V"
        set "FOUND=1"
    )
) else (
    set "RES="
    set "FOUND=0"
)

:CheckDefault
REM Если ключ не найден (FOUND=0), проверяем аргумент %2 (значение по умолчанию)
if "%FOUND%"=="0" (
    if not "%~2"=="" (
        set "RES=%~2"
        REM echo [LOG] Ключ не найден, установлено значение по умолчанию: %~2
    ) else (
        set "RES=NotFound"
        REM echo [LOG] Ключ не найден, дефолт не задан, RES=NotFound
    )
)

REM Очистка обрамляющих кавычек у найденного или дефолтного значения.
REM Важно: здесь нельзя сравнивать RES через обычное percent-expansion.
if defined RES (
    set "RES=!RES:"=!"
)

REM Финальное присвоение результата переменной с именем ключа
set "%~1=%RES%"

set "Configurator=0"
goto :eof


REM Функция: запись значения с пробелами
:WriteConfig
set "CONFIG_FILE=%USERPROFILE%\AppData\Roaming\GoodbyeZapret\config.txt"
REM Вызов: call :WriteConfig VariableName "Значение с пробелами"

set "TEMP_FILE=%~dp0config_temp.txt"
if exist "%TEMP_FILE%" del "%TEMP_FILE%"

set "found=0"

REM 1) Сохраняем ключ ДО shift
set "KEY=%~1"

REM 2) Значение берём из %~2 (одно аргументированное значение в кавычках)
set "VALUE=%~2"

REM Переписываем файл, меняя только нужную строку
for /f "usebackq tokens=1,* delims==" %%A in ("%CONFIG_FILE%") do (
    if /i "%%~A"=="!KEY!" (
        >>"%TEMP_FILE%" echo %%A="!VALUE!"
        set "found=1"
    ) else (
        >>"%TEMP_FILE%" echo %%A=%%B
    )
)

REM 3) Если ключа не было — добавляем
if "!found!"=="0" (
    >>"%TEMP_FILE%" echo !KEY!="!VALUE!"
)

move /y "%TEMP_FILE%" "%CONFIG_FILE%" >nul 2>&1
goto :eof

:DelConfig
set "CONFIG_FILE=%USERPROFILE%\AppData\Roaming\GoodbyeZapret\config.txt"
set "TEMP_FILE=%~dp0config_temp.txt"
if exist "%TEMP_FILE%" del "%TEMP_FILE%"
set "DELVAR=%~1"
for /f "tokens=1,* delims==" %%A in ("%CONFIG_FILE%") do (
    if /i not "%%A"=="!DELVAR!" (
        echo %%A=%%B>> "%TEMP_FILE%"
    )
)
move /y "%TEMP_FILE%" "%CONFIG_FILE%" >nul 2>&1
goto :eof


REM Функция: инициализация конфига из реестра
:InitConfigFromRegistry

REM Переключаемся на кодовую страницу, поддерживающую символы Unicode
chcp 850 >nul 2>&1
for /f "usebackq delims=" %%a in (`powershell -Command "(Get-CimInstance Win32_OperatingSystem).Caption"`) do (
    chcp 65001 >nul 2>&1    
    set "WinVersion=%%a"

    REM Проверяем, является ли система Windows 11
    echo !WinVersion! | find /i "Windows 11" >nul
    if not errorlevel 1 (
        set "WinVer=Windows 11"
        call :ui_info "Определяю версию Windows как Win11"
        reg add "HKEY_CURRENT_USER\Software\ALFiX inc.\GoodbyeZapret" /t REG_SZ /v "WinVer" /d "11" /f >nul 2>&1
    ) else (
        REM Проверяем, является ли система Windows 10
        echo !WinVersion! | find /i "Windows 10" >nul
        if not errorlevel 1 (
            set "WinVer=Windows 10"
            call :ui_info "Определяю версию Windows как Win10"
            reg add "HKEY_CURRENT_USER\Software\ALFiX inc.\GoodbyeZapret" /t REG_SZ /v "WinVer" /d "10" /f >nul 2>&1
        )
    )
)

set "CONFIG_FILE=%USERPROFILE%\AppData\Roaming\GoodbyeZapret\config.txt"
set "VARS=WinVer FirstLaunch GoodbyeZapret_Version GoodbyeZapret_Config GoodbyeZapret_ConfigPatch GoodbyeZapret_LastStartConfig GoodbyeZapret_LastWorkConfig GoodbyeZapret_Version_code"
set "REG_KEY=HKCU\Software\ALFiX inc.\GoodbyeZapret"

if exist "%CONFIG_FILE%" goto :eof

echo Инициализация config.txt из реестра...
if not exist "%USERPROFILE%\AppData\Roaming\GoodbyeZapret" mkdir "%USERPROFILE%\AppData\Roaming\GoodbyeZapret"
> "%CONFIG_FILE%" type nul

for %%V in (%VARS%) do (
    for /f "skip=2 tokens=2,*" %%A in ('reg query "%REG_KEY%" /v "%%V" 2^>nul') do (
        if not "%%B"=="" >>"%CONFIG_FILE%" echo %%V="%%B"
    )
)
goto :eof

:CDN_BypassLevelSelector
REM Проверяем текущее значение и переключаем на следующее по циклу
if /i "%CDN_BypassLevel%"=="off" (
    set "CDN_BypassLevel=base"
) else if /i "%CDN_BypassLevel%"=="base" (
    set "CDN_BypassLevel=full"
) else (
    REM Если значение max или переменная пуста/неизвестна — сбрасываем в off
    set "CDN_BypassLevel=off"
)

REM Записываем новое значение в реестр (системные переменные)
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v "CDN_BypassLevel" /t REG_SZ /d "%CDN_BypassLevel%" /f >nul

if defined CDN_BypassLevel (
    call :WriteConfig CDN_LVL "%CDN_BypassLevel%"
) else (
    echo ^[ERROR^] CDN_BypassLevel не определен
)

goto :MainMenu_without_ui_info

:ConfiguratorMenu
title Конфигуратор стратегий

REM Проверка статуса службы GoodbyeZapret
sc query "GoodbyeZapret" >nul 2>&1
if %errorlevel% equ 0 (
    set "GoodbyeZapretStart=Yes"
) else (
    set "GoodbyeZapretStart=No"
)

:UpdateLimits
:: Получаем количество стратегий для единственного движка Zapret2/winws2
"%ParentDirPath%\tools\config_builder\builder.exe" --get-limits > "%ParentDirPath%\tools\config_builder\config_builder_limits.bat"

if errorlevel 1 (
    echo [ERROR] Could not load limits
    set "MAX_YouTube=0" & set "MAX_YouTubeGoogleVideo=0" & set "MAX_YouTubeQuic=0" & set "MAX_Twitch=0" & set "MAX_Discord=0" & set "MAX_DiscordUpdate=0" & set "MAX_DiscordQuic=0" & set "MAX_DiscordMedia=0" & set "MAX_Hostlists=0" & set "MAX_STUN=0" & set "MAX_CDN=0" & set "MAX_CloudflareCDNTCP=0" & set "MAX_AmazonTCP=0" & set "MAX_AmazonUDP=0" & set "MAX_Custom=0"
) else if exist "%ParentDirPath%\tools\config_builder\config_builder_limits.bat" (
    call "%ParentDirPath%\tools\config_builder\config_builder_limits.bat"
    del "%ParentDirPath%\tools\config_builder\config_builder_limits.bat"
) else (
    echo [ERROR] Could not load limits
    set "MAX_YouTube=0" & set "MAX_YouTubeGoogleVideo=0" & set "MAX_YouTubeQuic=0" & set "MAX_Twitch=0" & set "MAX_Discord=0" & set "MAX_DiscordUpdate=0" & set "MAX_DiscordQuic=0" & set "MAX_DiscordMedia=0" & set "MAX_Hostlists=0" & set "MAX_STUN=0" & set "MAX_CDN=0" & set "MAX_CloudflareCDNTCP=0" & set "MAX_AmazonTCP=0" & set "MAX_AmazonUDP=0" & set "MAX_Custom=0"
)

set "Configurator=1" & call :ReadConfig YT 1
set "Configurator=1" & call :ReadConfig YTGV 1
set "Configurator=1" & call :ReadConfig YTQ 1
set "Configurator=1" & call :ReadConfig TW 0
set "Configurator=1" & call :ReadConfig DSUPD 1
set "Configurator=1" & call :ReadConfig DS 1
set "Configurator=1" & call :ReadConfig DSQ 1
set "Configurator=1" & call :ReadConfig DSMEDIA 1
set "Configurator=1" & call :ReadConfig BL 0
set "Configurator=1" & call :ReadConfig STUN 1
set "Configurator=1" & call :ReadConfig CDN 1
set "Configurator=1" & call :ReadConfig CFTCP 1
set "Configurator=1" & call :ReadConfig AMZTCP 1
set "Configurator=1" & call :ReadConfig AMZUDP 1
set "Configurator=1" & call :ReadConfig CUSTOM 0
set "Configurator=1" & call :ReadConfig CDN_LVL base

:MENU
cls
title GoodbyeZapret - Конфигуратор стратегий

:: Список всех переменных для проверки
set "CHECK_LIST=YT YTGV YTQ TW DSUPD DS DSQ DSMEDIA BL STUN CDN CFTCP AMZTCP AMZUDP CUSTOM"

:: Цикл по каждой переменной из списка
for %%V in (%CHECK_LIST%) do (
    :: Если значение переменной меньше 10
    if !%%V! LSS 10 (
        set "%%V_sp=  "
    ) else (
        set "%%V_sp= "
    )
)

echo.
echo    %COL%[36m╔════════════════════════════════════════════════════════════════════════════════════╗
echo    %COL%[36m║%COL%[90m [КЛАВИША]    Модуль               Текущее       ^(доступно^)                         %COL%[36m║
echo    %COL%[36m╠════════════════════════════════════════════════════════════════════════════════════╣

echo    %COL%[36m║   %COL%[96m[  1 ]%COL%[37m  YouTube                    %COL%[92m!YT!          !YT_sp!%COL%[90m(0-!MAX_YouTube!)
echo    %COL%[36m║   %COL%[96m[  2 ]%COL%[37m  YouTube GoogleVideo        %COL%[92m!YTGV!          !YTGV_sp!%COL%[90m(0-!MAX_YouTubeGoogleVideo!)
echo    %COL%[36m║   %COL%[96m[  3 ]%COL%[37m  YouTube QUIC               %COL%[92m!YTQ!          !YTQ_sp!%COL%[90m(0-!MAX_YouTubeQuic!)
echo    %COL%[36m║ 
echo    %COL%[36m║   %COL%[96m[  4 ]%COL%[37m  Twitch                     %COL%[92m!TW!          !TW_sp!%COL%[90m(0-!MAX_Twitch!)
echo    %COL%[36m║
echo    %COL%[36m║   %COL%[96m[  5 ]%COL%[37m  Discord Update             %COL%[92m!DSUPD!          !DSUPD_sp!%COL%[90m(0-!MAX_DiscordUpdate!)
echo    %COL%[36m║   %COL%[96m[  6 ]%COL%[37m  Discord                    %COL%[92m!DS!          !DS_sp!%COL%[90m(0-!MAX_Discord!)
echo    %COL%[36m║   %COL%[96m[  7 ]%COL%[37m  Discord QUIC               %COL%[92m!DSQ!          !DSQ_sp!%COL%[90m(0-!MAX_DiscordQuic!)
echo    %COL%[36m║   %COL%[96m[  8 ]%COL%[37m  Discord.media              %COL%[92m!DSMEDIA!          !DSMEDIA_sp!%COL%[90m(0-!MAX_DiscordMedia!)
echo    %COL%[36m║   %COL%[96m[  9 ]%COL%[37m  Discord STUN-VOICE         %COL%[92m!STUN!          !STUN_sp!%COL%[90m(0-!MAX_STUN!)
echo    %COL%[36m║
echo    %COL%[36m║   %COL%[96m[ 10 ]%COL%[37m  CDN                        %COL%[92m!CDN!          !CDN_sp!%COL%[90m(0-!MAX_CDN!)
echo    %COL%[36m║   %COL%[96m[ 11 ]%COL%[37m  Cloudflare CDN TCP         %COL%[92m!CFTCP!          !CFTCP_sp!%COL%[90m(0-!MAX_CloudflareCDNTCP!)
echo    %COL%[36m║   %COL%[96m[ 12 ]%COL%[37m  Amazon CDN TCP             %COL%[92m!AMZTCP!          !AMZTCP_sp!%COL%[90m(0-!MAX_AmazonTCP!)
echo    %COL%[36m║   %COL%[96m[ 13 ]%COL%[37m  Amazon CDN UDP             %COL%[92m!AMZUDP!          !AMZUDP_sp!%COL%[90m(0-!MAX_AmazonUDP!)
echo    %COL%[36m║
echo    %COL%[36m║   %COL%[96m[ 14 ]%COL%[37m  Hostlists                  %COL%[92m!BL!          !BL_sp!%COL%[90m(0-!MAX_Hostlists!)
echo    %COL%[36m║   %COL%[96m[ 15 ]%COL%[37m  Личные списки              %COL%[92m!CUSTOM!          !CUSTOM_sp!%COL%[90m(0-!MAX_Custom!)

echo    %COL%[36m╠════════════════════════════════════════════════════════════════════════════════════
echo    %COL%[36m║   %COL%[96m[ L ]%COL%[37m   Уровень модуля CDN        %COL%[92m!CDN_LVL!        %COL%[90m(off/base/full)
echo    %COL%[36m╚════════════════════════════════════════════════════════════════════════════════════╝
echo.
echo    %COL%[92m[ S ] Применить и Запустить обход
echo    %COL%[94m[ A ] Автоподбор стратегии
echo    %COL%[94m[ W ] Рабочие стратегии
echo    %COL%[92m[ С ] Быстро проверить обход
echo    %COL%[91m[ K ] Остановить обход
call :ResolveConfiguratorFixConfig
if defined ConfiguratorFixRel (
    if "%GoodbyeZapretStart%"=="Yes" (
        echo    %COL%[92m[ R ] Собрать стратегии и перезапустить службу
        echo    %COL%[91m[ D ] Удалить из автозапуска
    ) else (
        echo    %COL%[92m[ U ] Добавить в автозапуск
    )
)

echo.
echo    %COL%[90m[ P ] Открыть личные списки
echo    %COL%[90m[ I ] Инструкция   
echo    %COL%[90m[ B ] Назад
echo.
set /p "opt=%DEL%   %COL%[90m:> "


if /i "%opt%"=="S" goto START
if /i "%opt%"=="ы" goto START
if /i "%opt%"=="A" goto ConfiguratorAutoPicker
if /i "%opt%"=="ф" goto ConfiguratorAutoPicker
if /i "%opt%"=="W" goto ConfiguratorAutoShowResults
if /i "%opt%"=="ц" goto ConfiguratorAutoShowResults
if /i "%opt%"=="R" goto ConfiguratorRebuildRestart
if /i "%opt%"=="к" goto ConfiguratorRebuildRestart
if /i "%opt%"=="K" goto KILL
if /i "%opt%"=="л" goto KILL

if /i "%opt%"=="cfg" explorer "%USERPROFILE%\AppData\Roaming\GoodbyeZapret\configurator.txt"
if /i "%opt%"=="I" goto OpenConfiguratorInstructions
if /i "%opt%"=="ш" goto OpenConfiguratorInstructions
if /i "%opt%"=="P" goto OpenPersonalList
if /i "%opt%"=="з" goto OpenPersonalList
if /i "%opt%"=="B" goto MainMenu_without_ui_info
if /i "%opt%"=="И" goto MainMenu_without_ui_info
if /i "%opt%"=="C" goto START_with_checking
if /i "%opt%"=="с" goto START_with_checking

call :ResolveConfiguratorFixConfig
if not defined ConfiguratorFixRel goto ConfiguratorAfterAutostartHotkeys
if /i "%opt%"=="U" goto ConfiguratorInstallAutostart
if /i "%opt%"=="г" goto ConfiguratorInstallAutostart
if /i "%opt%"=="D" goto ConfiguratorRemoveAutostart
if /i "%opt%"=="в" goto ConfiguratorRemoveAutostart

:ConfiguratorAfterAutostartHotkeys

:: Проверки ввода с использованием полученных лимитов
if "%opt%"=="1" goto ConfiguratorSetYouTube
if "%opt%"=="2" goto ConfiguratorSetYouTubeGoogleVideo
if "%opt%"=="3" goto ConfiguratorSetYouTubeQuic
if "%opt%"=="4" goto ConfiguratorSetTwitch
if "%opt%"=="5" goto ConfiguratorSetDiscordUpdate
if "%opt%"=="6" goto ConfiguratorSetDiscord
if "%opt%"=="7" goto ConfiguratorSetDiscordQuic
if "%opt%"=="8" goto ConfiguratorSetDiscordMedia
if "%opt%"=="9" goto ConfiguratorSetSTUN
if "%opt%"=="10" goto ConfiguratorSetCDN
if "%opt%"=="11" goto ConfiguratorSetCloudflareCDNTCP
if "%opt%"=="12" goto ConfiguratorSetAmazonTCP
if "%opt%"=="13" goto ConfiguratorSetAmazonUDP
if "%opt%"=="14" goto ConfiguratorSetHostlists
if "%opt%"=="15" goto ConfiguratorSetCustom

if /i "%opt%"=="L" goto ConfiguratorSetCDNLevel
if /i "%opt%"=="д" goto ConfiguratorSetCDNLevel

goto MENU

:ConfiguratorInstallAutostart
cls
echo.
echo  [*] Сборка стратегий в конфиг на Zapret2 / winws2.exe...
call :BuildConfiguratorFix
call :ResolveConfiguratorFixConfig
if defined ConfiguratorFixRel (
    set "batFile=!ConfiguratorFixFile!"
    set "batRel=!ConfiguratorFixRel!"
)
set "PanelBack=Configurator"
call :remove_service_before_installing
if errorlevel 1 goto MENU
call :install_GZ_service
call :WriteConfig GoodbyeZapret_Config "ConfiguratorFix"
goto MENU

:ConfiguratorRebuildRestart
cls
call :ui_init
call :ui_hr
echo   %C_TITLE%Сборка стратегий и перезапуск службы%C_RESET%
call :ui_hr
echo.
call :ui_info "Собираю ConfiguratorFix на Zapret2 / winws2.exe..."
call :BuildConfiguratorFix
if errorlevel 1 (
    call :ui_err "Не удалось собрать стратегии."
    pause >nul
    goto MENU
)

call :ResolveConfiguratorFixConfig
if not defined ConfiguratorFixRel (
    call :ui_err "ConfiguratorFix не найден после сборки."
    pause >nul
    goto MENU
)

sc query "GoodbyeZapret" >nul 2>&1
if errorlevel 1 (
    call :ui_warn "Служба GoodbyeZapret не установлена."
    call :ui_warn "Сначала добавьте конфигуратор в автозапуск через пункт U."
    pause >nul
    goto MENU
)

sc qc "GoodbyeZapret" | find /I "ConfiguratorFix" >nul 2>&1
if errorlevel 1 (
    call :ui_warn "Текущая служба GoodbyeZapret установлена не на ConfiguratorFix."
    call :ui_warn "Пункт R применяет изменения только к службе, созданной из конфигуратора."
    call :ui_warn "Используйте U, чтобы один раз установить ConfiguratorFix в службу."
    pause >nul
    goto MENU
)

call :WriteConfig GoodbyeZapret_Config "ConfiguratorFix"
set "QuickRestartFromConfigurator=1"
goto QuickRestart

:ConfiguratorRemoveAutostart
set "PanelBack=Configurator"
call :remove_service
goto MENU

:ConfiguratorSetYouTube
call :ConfiguratorSetStrategy YT "YouTube" "!MAX_YouTube!"
goto MENU

:ConfiguratorSetYouTubeGoogleVideo
call :ConfiguratorSetStrategy YTGV "YouTube GoogleVideo" "!MAX_YouTubeGoogleVideo!"
goto MENU

:ConfiguratorSetYouTubeQuic
call :ConfiguratorSetStrategy YTQ "YouTube QUIC" "!MAX_YouTubeQuic!"
goto MENU

:ConfiguratorSetTwitch
call :ConfiguratorSetStrategy TW "Twitch" "!MAX_Twitch!"
goto MENU

:ConfiguratorSetDiscordUpdate
call :ConfiguratorSetStrategy DSUPD "Discord Update" "!MAX_DiscordUpdate!"
goto MENU

:ConfiguratorSetDiscord
call :ConfiguratorSetStrategy DS "Discord" "!MAX_Discord!"
goto MENU

:ConfiguratorSetDiscordQuic
call :ConfiguratorSetStrategy DSQ "Discord QUIC" "!MAX_DiscordQuic!"
goto MENU

:ConfiguratorSetDiscordMedia
call :ConfiguratorSetStrategy DSMEDIA "Discord.media" "!MAX_DiscordMedia!"
goto MENU

:ConfiguratorSetSTUN
call :ConfiguratorSetStrategy STUN "STUN" "!MAX_STUN!"
goto MENU

:ConfiguratorSetCDN
call :ConfiguratorSetStrategy CDN "CDN" "!MAX_CDN!"
if "!CDN!"=="0" set "CDN_LVL=off"
if !CDN! gtr 0 if /i "!CDN_LVL!"=="off" set "CDN_LVL=base"
goto MENU

:ConfiguratorSetCloudflareCDNTCP
call :ConfiguratorSetStrategy CFTCP "CloudflareCDN TCP" "!MAX_CloudflareCDNTCP!"
goto MENU

:ConfiguratorSetAmazonTCP
call :ConfiguratorSetStrategy AMZTCP "CDN Amazon TCP" "!MAX_AmazonTCP!"
goto MENU

:ConfiguratorSetAmazonUDP
call :ConfiguratorSetStrategy AMZUDP "CDN Amazon UDP" "!MAX_AmazonUDP!"
goto MENU

:ConfiguratorSetHostlists
call :ConfiguratorSetStrategy BL "Hostlists" "!MAX_Hostlists!"
goto MENU

:ConfiguratorSetCustom
call :ConfiguratorSetStrategy CUSTOM "личных списков" "!MAX_Custom!"
goto MENU

:ConfiguratorSetCDNLevel
if /i "!CDN_LVL!"=="off" (
    set "CDN_LVL=base"
) else if /i "!CDN_LVL!"=="base" (
    set "CDN_LVL=full"
) else (
    set "CDN_LVL=off"
)
goto MENU

:ConfiguratorSetStrategy
set "ConfiguratorTarget=%~1"
set "ConfiguratorLabel=%~2"
set "ConfiguratorMax=%~3"
if not defined ConfiguratorMax set "ConfiguratorMax=0"
echo(!ConfiguratorMax!| findstr /r "^[0-9][0-9]*$" >nul
if errorlevel 1 set "ConfiguratorMax=0"
set "val="
set /p "val=%DEL%   Введите стратегию для %ConfiguratorLabel% [0-!ConfiguratorMax!]: "

echo(!val!| findstr /r "^[0-9][0-9]*$" >nul
if errorlevel 1 (
    echo    Неверное значение. Введите число от 0 до !ConfiguratorMax!.
    echo.
    echo    %COL%[90mНажмите любую клавишу чтобы вернуться назад.
    pause >nul 
    exit /b
)

if !val! gtr !ConfiguratorMax! (
    echo    Неверное значение. Максимум - !ConfiguratorMax!.
    echo.
    echo    %COL%[90mНажмите любую клавишу чтобы вернуться назад.
    pause >nul 
) else (
    set "%ConfiguratorTarget%=!val!"
)
exit /b

:ConfiguratorAutoPicker
cls
title GoodbyeZapret - Автоподбор стратегий
echo.
echo  %COL%[36mВыберите модуль для автоподбора:
echo.
echo    %COL%[96m[ 1 ]%COL%[37m  YouTube
echo    %COL%[96m[ 2 ]%COL%[37m  YouTube GoogleVideo ^(Может работать не точно^)
echo.
echo    %COL%[96m[ 3 ]%COL%[37m  Twitch
echo.
echo    %COL%[96m[ 4 ]%COL%[37m  Discord Update
echo    %COL%[96m[ 5 ]%COL%[37m  Discord
echo.
echo    %COL%[96m[ 6 ]%COL%[37m  CDN
echo    %COL%[96m[ 7 ]%COL%[37m  CloudflareCDN TCP
echo    %COL%[96m[ 8 ]%COL%[37m  Amazon CDN TCP
echo.
echo    %COL%[96m[ 9 ]%COL%[37m  Hostlists
echo    %COL%[96m[ 10 ]%COL%[37m  Личные списки
echo.
echo    %COL%[90m[ B ] Назад
echo.
set /p "AutoChoice=%DEL%   %COL%[90m:> "

set "AutoVar="
set "AutoMaxVar="
set "AutoName="
set "AutoTrackedVars=YT YTGV YTQ TW DSUPD DS DSQ DSMEDIA STUN CDN CFTCP AMZTCP AMZUDP BL CUSTOM"

if /i "%AutoChoice%"=="B" goto MENU
if /i "%AutoChoice%"=="и" goto MENU
call :ConfiguratorAutoResolveChoice "%AutoChoice%"

if not defined AutoVar (
    echo.
    echo  %COL%[91m[WARN]%COL%[37m Неверный выбор модуля.
    timeout /t 1 >nul 2>&1
    goto ConfiguratorAutoPicker
)

call set "AutoMax=%%%AutoMaxVar%%%"
if not defined AutoMax set "AutoMax=0"
call set "AutoPrev=%%%AutoVar%%%"
for %%V in (!AutoTrackedVars!) do set "AutoPrev_%%V=!%%V!"
call :ConfiguratorAutoBackup

set "AutoZeroOthers=1"
echo.
echo  %COL%[36mОбнулить остальные стратегии на время автоподбора?%COL%[90m [Y / N]
set /p "AutoZeroChoice=%DEL%   %COL%[90m:> "
if /i "!AutoZeroChoice!"=="Y" set "AutoZeroOthers=1"
if /i "!AutoZeroChoice!"=="Н" set "AutoZeroOthers=1"
if /i "!AutoZeroChoice!"=="N" set "AutoZeroOthers=0"
if /i "!AutoZeroChoice!"=="Т" set "AutoZeroOthers=0"
set /a AutoIndex=0
set "AutoAlmostList="
set /a AutoAlmostCount=0
set "AutoFoundList="
set "AutoFirstFound="
set /a AutoFoundCount=0
call :ConfiguratorAutoUpdateTitle

:ConfiguratorAutoLoop
if !AutoIndex! gtr !AutoMax! goto ConfiguratorAutoComplete
call :ConfiguratorAutoSetTestVars
call :ConfiguratorAutoApply
call :ConfiguratorAutoCheck

if "!AutoCheckResult!"=="0" call :ConfiguratorAutoRegisterFound
if "!AutoCheckResult!"=="1" (
    set /a AutoAlmostCount+=1
    set "AutoAlmostList=!AutoAlmostList!!AutoIndex! "
)
set /a AutoIndex+=1
goto ConfiguratorAutoLoop

:ConfiguratorAutoComplete
if !AutoFoundCount! gtr 0 goto ConfiguratorAutoSave
goto ConfiguratorAutoNotFound

:ConfiguratorAutoSave
call :ConfiguratorAutoRestoreAll
for %%V in (!AutoVar!) do set "%%V=!AutoFirstFound!"
set /a AutoIndex=AutoFirstFound
call :ConfiguratorAutoApply
call :ConfiguratorAutoUpdateTitle
call :ConfiguratorAutoSaveFoundResults
echo.
echo  %COL%[92m[OK]%COL%[37m Найдены рабочие стратегии для %COL%[92m!AutoName!%COL%[37m: %COL%[92m!AutoFoundList!%COL%[37m.
echo  %COL%[93m[INFO]%COL%[37m Список сохранен для быстрого просмотра.
echo  %COL%[93m[INFO]%COL%[37m Применена первая найденная стратегия: %COL%[92m!AutoFirstFound!%COL%[37m.
pause >nul
goto MENU

:ConfiguratorAutoCancel
call :ConfiguratorAutoRestoreAll
set /a AutoIndex=AutoPrev
call :ConfiguratorAutoApply
echo.
echo  %COL%[90mВозвращено предыдущее значение %COL%[92m!AutoPrev!%COL%[90m для %COL%[92m!AutoName!%COL%[90m.
pause >nul
goto MENU

:ConfiguratorAutoNotFound
call :ConfiguratorAutoRestoreAll
set /a AutoIndex=AutoPrev
call :ConfiguratorAutoApply
echo.
echo  %COL%[91m[WARN]%COL%[37m Подходящая стратегия не найдена (0-!AutoMax!).
if !AutoAlmostCount! gtr 0 (
    echo  %COL%[93m[INFO]%COL%[37m Почти рабочие стратегии: %COL%[92m!AutoAlmostList!%COL%[37m
)
echo  %COL%[90mВозвращено значение %COL%[92m!AutoPrev!%COL%[90m для %COL%[92m!AutoName!%COL%[90m.
pause >nul
goto MENU

:ConfiguratorAutoApply
cls
call :ConfiguratorAutoUpdateTitle
echo.
echo  [*] Модуль: !AutoName!  Стратегия: !AutoIndex! (0-!AutoMax!)
echo  [*] Сборка стратегий в конфиг на Zapret2 / winws2.exe...
call :BuildConfiguratorFix

call :ConfiguratorAutoStopRunning
call :ResolveConfiguratorFixConfig
if defined ConfiguratorFixRel (
    echo  [*] Запуск...
    if /I "!ConfiguratorFixExt!"==".txt" (
        call :StartTextPreset "%ParentDirPath%\configs\Custom\ConfiguratorFix.txt"
    ) else (
        start "" "%ParentDirPath%\Configs\Custom\ConfiguratorFix.bat"
    )
)
echo  [*] Проверяем процесс обхода...
set "AutoProcessName=Winws2.exe"
call :WaitForProcessByName "!AutoProcessName!" 3
if errorlevel 1 (
    echo.
    echo %COL%[91m ОШИБКА: Процесс обхода ^(!AutoProcessName!^) НЕ ЗАПУЩЕН. %COL%[37m
    echo.
) else (
    echo  [*] Процесс обхода работает, ошибки не обнаружены
)
exit /b

:ConfiguratorAutoRegisterFound
if not defined AutoFirstFound set "AutoFirstFound=!AutoIndex!"
if defined AutoFoundList (
    set "AutoFoundList=!AutoFoundList!, !AutoIndex!"
) else (
    set "AutoFoundList=!AutoIndex!"
)
set /a AutoFoundCount+=1
call :ConfiguratorAutoUpdateTitle
echo.
echo  %COL%[92m[OK]%COL%[37m Найдена рабочая стратегия %COL%[92m!AutoIndex!%COL%[37m для %COL%[92m!AutoName!%COL%[37m.
exit /b

:ConfiguratorAutoUpdateTitle
if defined AutoFoundList (
    title GoodbyeZapret - Автоподбор - рабочие: !AutoFoundList!
) else (
    title GoodbyeZapret - Автоподбор - рабочие: -
)
exit /b

:WaitForProcessByName
set "WaitProcessName=%~1"
set "WaitProcessLimit=%~2"
if not defined WaitProcessLimit set "WaitProcessLimit=3"
set /a WaitProcessAttempts=0
:WaitForProcessByNameLoop
tasklist /FI "IMAGENAME eq !WaitProcessName!" 2>nul | find /I "!WaitProcessName!" >nul
if not errorlevel 1 exit /b 0
if !WaitProcessAttempts! GEQ !WaitProcessLimit! exit /b 1
timeout /t 1 /nobreak >nul 2>&1
set /a WaitProcessAttempts+=1
goto WaitForProcessByNameLoop

:ConfiguratorAutoResolveChoice
set "AutoVar="
set "AutoMaxVar="
set "AutoName="
if "%~1"=="1" (set "AutoVar=YT"     & set "AutoMaxVar=MAX_YouTube"            & set "AutoName=YouTube")
if "%~1"=="2" (set "AutoVar=YTGV"   & set "AutoMaxVar=MAX_YouTubeGoogleVideo" & set "AutoName=YouTube GoogleVideo")
if "%~1"=="3" (set "AutoVar=TW"     & set "AutoMaxVar=MAX_Twitch"             & set "AutoName=Twitch")
if "%~1"=="4" (set "AutoVar=DSUPD"  & set "AutoMaxVar=MAX_DiscordUpdate"      & set "AutoName=Discord Update")
if "%~1"=="5" (set "AutoVar=DS"     & set "AutoMaxVar=MAX_Discord"            & set "AutoName=Discord")
if "%~1"=="6" (set "AutoVar=CDN"    & set "AutoMaxVar=MAX_CDN"                & set "AutoName=CDN")
if "%~1"=="7" (set "AutoVar=CFTCP"  & set "AutoMaxVar=MAX_CloudflareCDNTCP"   & set "AutoName=CloudflareCDN TCP")
if "%~1"=="8" (set "AutoVar=AMZTCP" & set "AutoMaxVar=MAX_AmazonTCP"          & set "AutoName=Amazon CDN TCP")
if "%~1"=="9" (set "AutoVar=BL"     & set "AutoMaxVar=MAX_Hostlists"          & set "AutoName=Hostlists")
if "%~1"=="10" (set "AutoVar=CUSTOM" & set "AutoMaxVar=MAX_Custom"            & set "AutoName=Личные списки")
exit /b

:ConfiguratorAutoStopRunning
taskkill /F /IM winws2.exe /T >nul 2>&1
exit /b

:ConfiguratorAutoSetTestVars
if "!AutoZeroOthers!"=="1" (
    for %%V in (!AutoTrackedVars!) do set "%%V=0"
)
for %%V in (!AutoVar!) do set "%%V=!AutoIndex!"
exit /b

:ConfiguratorAutoRestoreAll
for %%V in (!AutoTrackedVars!) do set "%%V=!AutoPrev_%%V!"
exit /b

:ConfiguratorAutoBackup
set "AutoBackupFile=%USERPROFILE%\AppData\Roaming\GoodbyeZapret\autopick_backup.txt"
if not exist "%USERPROFILE%\AppData\Roaming\GoodbyeZapret" md "%USERPROFILE%\AppData\Roaming\GoodbyeZapret" >nul 2>&1
> "%AutoBackupFile%" echo # GoodbyeZapret AutoPick backup
>>"%AutoBackupFile%" echo Date=%DATE% Time=%TIME%
>>"%AutoBackupFile%" echo YT="!YT!"
>>"%AutoBackupFile%" echo YTGV="!YTGV!"
>>"%AutoBackupFile%" echo YTQ="!YTQ!"
>>"%AutoBackupFile%" echo TW="!TW!"
>>"%AutoBackupFile%" echo DSUPD="!DSUPD!"
>>"%AutoBackupFile%" echo DS="!DS!"
>>"%AutoBackupFile%" echo DSQ="!DSQ!"
>>"%AutoBackupFile%" echo DSMEDIA="!DSMEDIA!"
>>"%AutoBackupFile%" echo STUN="!STUN!"
>>"%AutoBackupFile%" echo CDN="!CDN!"
>>"%AutoBackupFile%" echo CFTCP="!CFTCP!"
>>"%AutoBackupFile%" echo AMZTCP="!AMZTCP!"
>>"%AutoBackupFile%" echo AMZUDP="!AMZUDP!"
>>"%AutoBackupFile%" echo BL="!BL!"
>>"%AutoBackupFile%" echo CUSTOM="!CUSTOM!"
exit /b

:ConfiguratorAutoResultsPath
set "AutoResultsDir=%USERPROFILE%\AppData\Roaming\GoodbyeZapret"
set "AutoResultsFile=!AutoResultsDir!\autopick_results.txt"
exit /b

:ConfiguratorAutoSaveFoundResults
call :ConfiguratorAutoResultsPath
if not exist "!AutoResultsDir!" md "!AutoResultsDir!" >nul 2>&1
set "AutoResultsTemp=%TEMP%\gz_autopick_results.tmp"
if exist "!AutoResultsTemp!" del /q "!AutoResultsTemp!" >nul 2>&1

if exist "!AutoResultsFile!" (
    for /f "usebackq delims=" %%L in ("!AutoResultsFile!") do (
        set "AutoResultsLine=%%L"
        set "AutoResultsKey="
        for /f "tokens=1 delims=|" %%K in ("!AutoResultsLine!") do set "AutoResultsKey=%%K"
        if /i not "!AutoResultsKey!"=="!AutoVar!" >>"!AutoResultsTemp!" echo(!AutoResultsLine!
    )
)

>>"!AutoResultsTemp!" echo(!AutoVar!^|!AutoName!^|%DATE% %TIME%^|!AutoFoundList!^|!AutoFirstFound!
move /y "!AutoResultsTemp!" "!AutoResultsFile!" >nul 2>&1
exit /b

:ConfiguratorAutoShowResults
cls
title GoodbyeZapret - Рабочие стратегии
call :ConfiguratorAutoResultsPath
echo.
echo  %COL%[36mСохраненные рабочие стратегии:%COL%[37m
echo.

if not exist "!AutoResultsFile!" (
    echo  %COL%[90mПока ничего не сохранено. Запустите автоподбор стратегии.
    echo.
    echo  %COL%[90mНажмите любую клавишу чтобы вернуться назад.
    pause >nul
    goto MENU
)

set "AutoResultsAny=0"
for /f "usebackq tokens=1-5 delims=|" %%A in ("!AutoResultsFile!") do (
    set "AutoResultsAny=1"
    echo  %COL%[96m%%B%COL%[37m
    echo    Работали: %COL%[92m%%D%COL%[37m
    echo    Проверено: %COL%[90m%%C%COL%[37m
    echo.
    echo  %COL%[90mНажмите любую клавишу чтобы вернуться назад.
)

if "!AutoResultsAny!"=="0" (
    echo  %COL%[90mПока ничего не сохранено. Запустите автоподбор стратегии.
    echo.
    echo  %COL%[90mНажмите любую клавишу чтобы вернуться назад.
)
pause >nul
goto MENU

:ConfiguratorAutoCheck
set "AutoCheckResult=2"
set "AutoGitPath=/ALFiX01/GoodbyeZapret/main/GoodbyeZapret_Version"
set "AutoDomainFileDefault=%ParentDirPath%\tools\Config_Check\domains.txt"
set "AutoDomainFile=%AutoDomainFileDefault%"
set "AutoModuleFile="
set "AutoDomainUsedModule=0"

call :ConfiguratorAutoResolveDomainFile

if defined AutoModuleFile if exist "!AutoModuleFile!" (
    set "AutoDomainFile=!AutoModuleFile!"
    set "AutoDomainUsedModule=1"
)

if not defined CURL (
    if exist "%ParentDirPath%\tools\curl\curl.exe" (
        set CURL="%ParentDirPath%\tools\curl\curl.exe"
    ) else (
        set "CURL=curl"
    )
)

:ConfiguratorAutoCheck_ReadDomains
set "AutoFailed=0"
set "AutoTotal=0"
set "AutoFailedDomains="
set "AutoSuccessCount=0"
echo.
if "!AutoDomainUsedModule!"=="1" (
    echo  [*] Автопроверка доменов ^(модульный список^)...
) else (
    echo  [*] Автопроверка доменов...
)

if exist "!AutoDomainFile!" (
    for /f "usebackq delims=" %%D in ("!AutoDomainFile!") do (
        set "AutoLine=%%D"
        if defined AutoLine (
            for /f "tokens=* delims= " %%L in ("!AutoLine!") do set "AutoLine=%%L"
            if "!AutoLine:~0,3!"=="ï»¿" set "AutoLine=!AutoLine:~3!"
            if defined AutoLine if not "!AutoLine:~0,1!"=="#" call :ConfiguratorAutoCheckOne "!AutoLine!"
        )
    )
) else (
    for %%D in (rr6---sn-jvhnu5g-n8vy.googlevideo.com i.ytimg.com/vi/dQw4w9WgXcQ/maxresdefault.jpg discord.com cloudflare.com aws.amazon.com goodbyezapret.crabdance.com/GoodbyeZapret_Version) do (
        call :ConfiguratorAutoCheckOne "%%D"
    )
)

if !AutoTotal! LEQ 0 (
    if "!AutoDomainUsedModule!"=="1" (
        set "AutoDomainFile=!AutoDomainFileDefault!"
        set "AutoDomainUsedModule=0"
        goto ConfiguratorAutoCheck_ReadDomains
    )
    set "AutoCheckResult=2"
    echo  ^[WARN^] Список доменов пуст.
    exit /b
)

set /a AutoSuccessCount=AutoTotal-AutoFailed

if /i "!AutoVar!"=="YTGV" (
    if !AutoSuccessCount! GEQ 1 (
        set "AutoCheckResult=0"
        echo  ^[OK^] Для YouTube GoogleVideo доступен хотя бы один домен ^(!AutoSuccessCount!/!AutoTotal!^).
        exit /b
    )
)

if !AutoFailed! EQU 0 (
    set "AutoCheckResult=0"
    echo  ^[OK^] Все домены доступны.
    exit /b
)

if !AutoFailed! EQU 1 (
    set "AutoCheckResult=1"
    echo  ^[WARN^] Недоступен 1 домен: !AutoFailedDomains!
    exit /b
)

set "AutoCheckResult=2"
echo  ^[FAIL^] Недоступно доменов: !AutoFailed!
exit /b

:ConfiguratorAutoCheckOne
set "AutoUrlRaw=%~1"
if /i "!AutoUrlRaw!"=="raw.githubusercontent.com" set "AutoUrlRaw=goodbyezapret.crabdance.com/GoodbyeZapret_Version"
set "AutoUrl=!AutoUrlRaw!"
if /i not "!AutoUrl:~0,7!"=="http://" if /i not "!AutoUrl:~0,8!"=="https://" set "AutoUrl=https://!AutoUrl!"
set /a AutoTotal+=1

set "AutoCode="
set "AutoCodeFile=%TEMP%\gz_autocode.tmp"
if exist "!AutoCodeFile!" del /q "!AutoCodeFile!" >nul 2>&1
%CURL% -L -k --connect-timeout 1 -m 3 -s -o NUL -w "%%{http_code}" "!AutoUrl!" > "!AutoCodeFile!"
if exist "!AutoCodeFile!" (
    set /p "AutoCode="<"!AutoCodeFile!"
    del /q "!AutoCodeFile!" >nul 2>&1
)

if not defined AutoCode (
    set /a AutoFailed+=1
    set "AutoFailedDomains=!AutoFailedDomains!!AutoUrlRaw! "
    exit /b
)

REM Если AutoCode остался 000 или пустой — значит связи нет вообще (ошибка curl)
if "!AutoCode!"=="000" goto :AutoCheckFail
if not defined AutoCode goto :AutoCheckFail

REM Если сервер ответил ЛЮБЫМ кодом (200, 302, 403, 404, 500) — домен жив.
REM Выходим как "успех"
exit /b

:AutoCheckFail
set /a AutoFailed+=1
set "AutoFailedDomains=!AutoFailedDomains!!AutoUrlRaw! "
exit /b

:ConfiguratorAutoResolveDomainFile
set "AutoModuleFile="
if /i "!AutoVar!"=="YT"      set "AutoModuleFile=%ParentDirPath%\tools\Config_Check\domains\youtube.txt"
if /i "!AutoVar!"=="YTGV"    set "AutoModuleFile=%ParentDirPath%\tools\Config_Check\domains\youtube_googlevideo.txt"
if /i "!AutoVar!"=="TW"      set "AutoModuleFile=%ParentDirPath%\tools\Config_Check\domains\twitch.txt"
if /i "!AutoVar!"=="DSUPD"   set "AutoModuleFile=%ParentDirPath%\tools\Config_Check\domains\discord_update.txt"
if /i "!AutoVar!"=="DS"      set "AutoModuleFile=%ParentDirPath%\tools\Config_Check\domains\discord.txt"
if /i "!AutoVar!"=="CDN"     set "AutoModuleFile=%ParentDirPath%\tools\Config_Check\domains\cdn.txt"
if /i "!AutoVar!"=="CFTCP"   set "AutoModuleFile=%ParentDirPath%\tools\Config_Check\domains\cloudflare_tcp.txt"
if /i "!AutoVar!"=="AMZTCP"  set "AutoModuleFile=%ParentDirPath%\tools\Config_Check\domains\amazon_tcp.txt"
if /i "!AutoVar!"=="BL"      set "AutoModuleFile=%ParentDirPath%\tools\Config_Check\domains\blacklist.txt"
if /i "!AutoVar!"=="CUSTOM"  set "AutoModuleFile=%ParentDirPath%\tools\Config_Check\domains\custom.txt"
exit /b

:BuildConfiguratorFix
"%ParentDirPath%\tools\config_builder\builder.exe" --youtube !YT! --youtubegooglevideo !YTGV! --youtubequic !YTQ! --twitch !TW! --discordupdate !DSUPD! --discord !DS! --discordquic !DSQ! --discordmedia !DSMEDIA! --blacklist !BL! --stun !STUN! --cdn !CDN! --cloudflarecdntcp !CFTCP! --amazontcp !AMZTCP! --amazonudp !AMZUDP! --custom !CUSTOM! --cdn-level !CDN_LVL!
exit /b %ERRORLEVEL%

:START
cls
echo.

echo  [*] Сборка стратегий в конфиг на Zapret2 / winws2.exe...
call :BuildConfiguratorFix

call :ResolveConfiguratorFixConfig
if defined ConfiguratorFixRel (
    echo  [*] Запуск...
    if /I "!ConfiguratorFixExt!"==".txt" (
        call :StartTextPreset "%ParentDirPath%\configs\Custom\ConfiguratorFix.txt"
    ) else (
        start "" "%ParentDirPath%\Configs\Custom\ConfiguratorFix.bat"
    )
)
echo  [*] Проверяем процесс обхода...
set "BypassProcessName=Winws2.exe"
call :WaitForProcessByName "!BypassProcessName!" 3
if errorlevel 1 (
    echo.
    echo %COL%[91m ОШИБКА: Процесс обхода ^(!BypassProcessName!^) НЕ ЗАПУЩЕН. %COL%[37m
    echo.
) else (
    echo  [*] Процесс обхода работает, ошибки не обнаружены
    timeout /t 2 >nul 2>&1
)
goto MENU

:START_with_checking
cls
echo.

echo  [*] Сборка стратегий в конфиг на Zapret2 / winws2.exe...
call :BuildConfiguratorFix

call :ResolveConfiguratorFixConfig
if defined ConfiguratorFixRel (
    echo  [*] Запуск...
    if /I "!ConfiguratorFixExt!"==".txt" (
        call :StartTextPreset "%ParentDirPath%\configs\Custom\ConfiguratorFix.txt"
    ) else (
        start "" "%ParentDirPath%\Configs\Custom\ConfiguratorFix.bat"
    )
)
echo  [*] Проверяем процесс обхода...
set "BypassProcessName=Winws2.exe"
call :WaitForProcessByName "!BypassProcessName!" 3
if errorlevel 1 (
    echo.
    echo %COL%[91m ОШИБКА: Процесс обхода ^(!BypassProcessName!^) НЕ ЗАПУЩЕН. %COL%[37m
    echo.
) else (
    echo  [*] Процесс обхода работает, ошибки не обнаружены
    timeout /t 2 >nul 2>&1
)
if exist "%ParentDirPath%\tools\Config_Check\config_check.exe" (
    cls
    echo %COL%[37m
    REM Цветной текст
    for /F "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do (set "DEL=%%a" & set "COL=%%b")
    "%ParentDirPath%\tools\Config_Check\config_check.exe" "!batFile!"
)
goto MENU

:KILL
echo  [*] Завершаю работу winws2...
taskkill /F /IM winws2.exe /T >nul 2>&1
goto MENU

:OpenPersonalList
explorer "%ParentDirPath%\lists\ipset-custom.txt"
explorer "%ParentDirPath%\lists\list-custom.txt"
goto MENU

:FinlandDiscordHostSelector
set "HOSTS=%hostspath%"

if /i "%FinlandDiscordHost%"=="off" (
    rem На всякий случай сначала чистим старый блок, потом добавляем свежий
    call :ui_info "Добавляю записи в файл hosts..."
    call :AddFinlandDiscordHost

    timeout /t 2 >nul
    ipconfig /flushdns >nul

) else (
    call :ui_info "Удаляю записи из файла hosts..."
    call :RemoveFinlandDiscordHosts

    timeout /t 2 >nul
    ipconfig /flushdns >nul
)

goto MenuBypassSettings


:AddFinlandDiscordHost
>>"%HOSTS%" echo ### Discord Finland Media Servers BEGIN
rem Добавляем основные домены через прокси
>>"%HOSTS%" echo 23.227.38.74 discord.com
>>"%HOSTS%" echo 23.227.38.74 gateway.discord.gg
>>"%HOSTS%" echo 23.227.38.74 updates.discord.com
>>"%HOSTS%" echo 23.227.38.74 cdn.discordapp.com
>>"%HOSTS%" echo 23.227.38.74 status.discord.com
>>"%HOSTS%" echo 23.227.38.74 cdn.prod.website-files.com

rem Добавляем голосовые сервера (finland)
for /l %%N in (10001,1,10199) do (
    >>"%HOSTS%" echo 104.25.158.178 finland%%N.discord.media
)
>>"%HOSTS%" echo ### Discord Finland Media Servers END
goto :eof


:RemoveFinlandDiscordHosts
chcp 850 >nul 2>&1
rem Снимаем атрибут "Только чтение" для надежности
attrib -r "%HOSTS%"

rem Исправленная версия: читаем в переменную $txt, затем фильтруем и записываем
powershell -Command "$path = $env:windir + '\System32\drivers\etc\hosts'; $txt = Get-Content $path; $txt | Where-Object { $_ -notmatch 'Discord Finland Media Servers' -and $_ -notmatch 'finland.*\.discord\.media' -and $_ -notmatch '23\.227\.38\.74' } | Set-Content $path -Force"

chcp 65001 >nul 2>&1
goto :eof

:TwitchHostSelector
set "HOSTS=%hostspath%"

if /i "%TwitchHost%"=="off" (
    rem На всякий случай сначала чистим старый блок, потом добавляем свежий
    call :ui_info "Добавляю записи в файл hosts..."
    call :AddTwitchHosts

    timeout /t 2 >nul
    ipconfig /flushdns >nul

) else (
    call :ui_info "Удаляю записи из файла hosts..."
    call :RemoveTwitchHosts

    timeout /t 2 >nul
    ipconfig /flushdns >nul
)

goto MenuBypassSettings


:AddTwitchHosts
>>"%HOSTS%" echo ### Twitch Servers BEGIN
>>"%HOSTS%" echo 185.68.247.42 usher.ttvnw.net
>>"%HOSTS%" echo 185.68.247.42 gql.twitch.tv
>>"%HOSTS%" echo ### Twitch Servers END
goto :eof


:RemoveTwitchHosts
chcp 850 >nul 2>&1
rem Сначала снимаем атрибут "Только чтение", если он есть, чтобы избежать ошибок доступа
attrib -r "%HOSTS%"

rem Исправленная команда: читаем в переменную $txt, затем фильтруем и сохраняем.
rem Это разрывает одновременное чтение и запись.
powershell -Command "$path = $env:windir + '\System32\drivers\etc\hosts'; $txt = Get-Content $path; $txt | Where-Object { $_ -notmatch 'Twitch Servers' -and $_ -notmatch '185.68.247.42' } | Set-Content $path -Force"

chcp 65001 >nul 2>&1
goto :eof


:YoutubeHostsSelector
set "HOSTS=%hostspath%"

if /i "%YoutubeHost%"=="off" (
    rem На всякий случай сначала чистим старый блок, потом добавляем свежий
    call :ui_info "Добавляю записи в файл hosts..."
    call :AddYoutubeHosts

    timeout /t 2 >nul
    ipconfig /flushdns >nul

) else (
    call :ui_info "Удаляю записи из файла hosts..."
    call :RemoveYoutubeHosts

    timeout /t 2 >nul
    ipconfig /flushdns >nul
)

goto MenuBypassSettings

:AddYoutubeHosts
>>"%HOSTS%" echo ### YouTube TCP Servers BEGIN
>>"%HOSTS%" echo 142.250.117.93 www.youtube.com
>>"%HOSTS%" echo ### YouTube TCP Servers END
goto :eof

:RemoveYoutubeHosts
chcp 850 >nul 2>&1
rem Снимаем атрибут "Только чтение" для надежности
attrib -r "%HOSTS%"

rem Исправленная логика: читаем в $txt, потом пишем
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p='%HOSTS%'; if(-not (Test-Path -LiteralPath $p)) { exit }; $t=Get-Content -LiteralPath $p -Raw -ErrorAction SilentlyContinue; if($null -eq $t){$t=''}; $re='(?ms)^\s*### YouTube TCP Servers BEGIN\s*$.*?^\s*### YouTube TCP Servers END\s*$\r?\n?'; $t=[regex]::Replace($t,$re,''); Set-Content -LiteralPath $p -Value $t -Force"

chcp 65001 >nul 2>&1
goto :eof

:timer_start
set start_time=%time%
goto :eof

:timer_end
set end_time=%time%

:: Парсинг начального времени
for /f "tokens=1-4 delims=:., " %%a in ("%start_time%") do (
    set /a start_h=%%a
    set /a start_m=100%%b %% 100
    set /a start_s=100%%c %% 100
    set /a start_ms=100%%d %% 100
)

:: Парсинг конечного времени
for /f "tokens=1-4 delims=:., " %%a in ("%end_time%") do (
    set /a end_h=%%a
    set /a end_m=100%%b %% 100
    set /a end_s=100%%c %% 100
    set /a end_ms=100%%d %% 100
)

:: Вычисление разницы
set /a total_ms=(%end_h%-%start_h%)*3600000 + (%end_m%-%start_m%)*60000 + (%end_s%-%start_s%)*1000 + (%end_ms%-%start_ms%)

echo Выполнение заняло: %total_ms% миллисекунд
goto :eof
